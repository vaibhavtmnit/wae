const {test} = require('node:test');
const assert = require('node:assert/strict');
const {parseMeta, merge, textExport, inferOrder, identity} = require('./core.js');
test('dates preserve displayed time and explicit date order', () => {
  assert.equal(parseMeta('[9:04 PM, 10/11/2026] Alice: ', 'dmy').date, '2026-11-10');
  assert.equal(parseMeta('[9:04 PM, 10/11/2026] Alice: ', 'mdy').date, '2026-10-11');
  assert.equal(parseMeta('[12:04 AM, 20/10/26] Alice: ', 'dmy').time, '00:04:00');
  assert.equal(parseMeta('[12:04 PM, 20/10/26] Alice: ', 'dmy').time, '12:04:00');
  assert.equal(parseMeta('[21:04, 2026-10-20] A: B: ', 'dmy').sender, 'A: B');
});
test('automatic date detection refuses ambiguous or conflicting evidence', () => {
  assert.equal(inferOrder(['[09:00, 10/11/2026] A: ']), null);
  assert.equal(parseMeta('[09:00, 10/11/2026] A: ', 'auto'), null);
  assert.equal(inferOrder(['[09:00, 20/10/2026] A: ']), 'dmy');
  assert.equal(inferOrder(['[09:00, 10/20/2026] A: ']), 'mdy');
  assert.throws(() => inferOrder(['[09:00, 20/10/2026] A: ', '[09:00, 10/20/2026] A: ']), /Conflicting/);
});
test('localized digits and bidi marks are parsed without altering raw metadata', () => {
  const raw='[٠٩:٠٤, ٢٠/١٠/٢٠٢٦] \u200fAlice: ';
  assert.equal(parseMeta(raw,'dmy').date,'2026-10-20');
  assert.equal(parseMeta(raw,'dmy').rawMetadata,raw);
  assert.equal(parseMeta('[०९:०४, २०/१०/२०२६] A: ','dmy').time,'09:04:00');
});
test('resume preserves previously captured rich content and files', () => {
  const old={key:'id',text:'original',attachments:['report.pdf']};
  assert.deepEqual(merge([old],[{key:'id',text:'',attachments:[]}])[0],old);
  assert.equal(identity('false_123@c.us_ABC'),'123@c.us');
  assert.equal(identity('unknown'),null);
});
test('invalid dates and unsupported metadata remain unparsed', () => {
  for (const meta of ['[09:00, 31/02/2026] A: ', '[25:00, 20/10/2026] A: ', 'system event']) assert.equal(parseMeta(meta, 'dmy'), null);
});
test('resume retains previous work and distinct stable message IDs', () => {
  const m = {date:'2026-10-20',time:'09:00:00',text:'same',attachments:[]};
  const old = [{...m,key:'one'}, {...m,key:'two'}];
  const result = merge(old, [{...m,key:'two'}, {...m,key:'three',time:'08:00:00'}]);
  assert.equal(result.length, 3);
  assert.equal(result[0].key, 'three');
  assert.equal(merge(result, []).length, 3);
  assert.equal(old.length, 2);
});
test('TXT includes coverage and attachment name without media content', () => {
  const text = textExport({start:'2026-10-01',end:'2026-10-20'}, {name:'Alice',status:'partial',reason:'Interrupted',messages:[{date:'2026-10-20',time:'09:00:00',sender:'Alice',text:'Report',attachments:['report.pdf']}]});
  assert.match(text, /Status: partial/);
  assert.match(text, /Coverage: Interrupted/);
  assert.match(text, /09:00:00\] Alice: Report/);
  assert.match(text, /Attachment: report.pdf/);
});
