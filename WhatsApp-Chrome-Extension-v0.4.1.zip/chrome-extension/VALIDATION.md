# Validation — 2026-10-20

Version 0.4.1. Data-engine validation below was completed for 0.4.0; the 0.4.1 filename update also passed JavaScript syntax checking and the native pagination/export Chromium test. All WhatsApp pages were synthetic local fixtures; no real account/profile or live chat content was used.

## Default data-store engine

`python chrome-extension/data_browser_test.py`: **10 tests passed** (17 seconds in the final run).

The fixture contains **no chat rows, conversation headers, scrollers, or message DOM**. A fake Meta `require` exports chat/message collections, account identity and database/history-loading interfaces with the shapes inspected in public WhatsApp library sources. Tests use Chrome's actual `scripting.executeScript` MAIN-world execution, message routing, account/lease authorization, IndexedDB transactions and UI controls.

Verified:

- Chat discovery uses stable IDs, distinguishes duplicate names, and includes available archived chats.
- Database cursor pagination retrieves exactly 180 selected-date records out of 260 total, even though only the newest 20 are cached as models. Cursor reconstruction works when older queried messages are absent from the model cache.
- Earlier-message collection loading works when database query functions are absent.
- Group senders, document/image captions, original document filenames, missing-filename placeholders, same-second duplicate text, and outgoing messages are preserved. Media keys and thumbnail body data are not exported.
- Tab reload retains a committed cursor and saved records. Transient database failure is retried without losing records or duplicating IDs.
- Resume after 250 new messages arrives catches all pages up to the old watermark and continues older history, producing exactly 430 unique selected-date messages.
- New outgoing messages after the last-received anchor are included.
- Wrong-account and wrong-chat results are rejected with zero records from the wrong source saved.
- Actual Find chats → checkbox → dates → Start new export uses the default data engine, displays progress, and exports the expected records.
- MAIN-world data reads from a control-page sender instead of an authorized WhatsApp runner are rejected.

## Shared logic and legacy engine

- `node --test chrome-extension/core.test.cjs`: **7 tests passed** for date parsing, localized digits, stable identities, resume merging, content preservation and TXT formatting.
- The **16 legacy/shared browser tests passed** during this version's development (as part of a 23-test run before separating the data test import). They cover virtualized DOM history, rollback/concurrent-run fencing, Blob download completion, reload/resume, chat changes, unsupported date/scroll layouts, worker restart, emoji/replies/files, real Start-button validation and timeout recovery, and progress counters. The final data suite was rerun separately after data cursor/newest-message changes; those changes do not alter the legacy extraction algorithm. A final added guard also rejects a legacy conversation ID that differs from a stable selected ID.
- JavaScript files passed `node --check`; the manifest parsed successfully.

## Limits of this evidence

An additional targeted legacy test passed after the final guard: a visible conversation ID different from the stable selected ID is rejected before any message is saved. There were 17 passing legacy/shared cases across these runs.

These are **fixture integration tests, not confirmation that the user's live WhatsApp session works**. They test a materially different retrieval path from the failed DOM scraper, but cannot prove that every current WhatsApp deployment exposes these unofficial modules or that all device/server history is present. No live SaveMyChat/WAExport internals were verified. See SOURCES.md for what was inspected and what remains inference.

Very large real accounts, all media/message types, account-ID migrations, live runtime variants, actual browser power loss during a transaction, and full server-history completeness were not validated. Runtime capabilities and read failures are reported rather than replaced by silent DOM fallback or a completeness claim. Perform a small known-range live acceptance export and reload/resume before relying on a large job.
