# Extraction research — 2026-10-20

The previous implementation scraped rendered WhatsApp messages. Repeated live failures showed that passing synthetic DOM tests did not establish compatibility with the user's WhatsApp layout. Version 0.4 adds a separate, default data-store engine instead of further dependence on clicking/scrolling the page.

## Products requested for comparison

- [SaveMyChat content overview](https://wa.dser.io/content): describes local exports with sender/timestamps and media, including JSON/Excel/HTML formats.
- [WAExport guide](https://waexports.wadesk.io/guide): describes selected-chat/date-range export and local archive files.
- [WAExport privacy policy](https://waexports.wadesk.io/privacy-policy): describes processing WhatsApp Web content locally.

These public pages describe features and data handling, not the exact extraction code. We did **not** verify which internal library either commercial product uses. No closed-source extension code or licensing/payment controls were copied or bypassed.

## Verifiable implementation references

- [WA-JS getMessages documentation](https://wppconnect.io/wa-js/functions/chat.getMessages.html): chat ID and message-ID based paging.
- [WA-JS getMessages implementation](https://github.com/wppconnect-team/wa-js/blob/main/src/chat/functions/getMessages.ts): current/legacy database queries, cursor anchors and raw message records.
- [whatsapp-web.js Chat.fetchMessages](https://github.com/wwebjs/whatsapp-web.js/blob/main/src/structures/Chat.js): chat message collections and `WAWebChatLoadMessages.loadEarlierMsgs({chat})`.
- [whatsapp-web.js Client source](https://github.com/wwebjs/whatsapp-web.js/blob/main/src/Client.js): `WAWebCollections` stores and WhatsApp module access.
- [WA-JS loader](https://github.com/wppconnect-team/wa-js/blob/main/src/loader/index.ts): Meta loader `require`/`importNamespace` and runtime readiness.
- [WA-JS MsgModel](https://github.com/wppconnect-team/wa-js/blob/main/src/whatsapp/models/MsgModel.ts): timestamp, sender, caption, filename and media fields.
- [WA-JS user identity](https://github.com/wppconnect-team/wa-js/blob/main/src/conn/functions/getMyUserWid.ts): signed-in account identity access.
- [Chrome scripting API](https://developer.chrome.com/docs/extensions/reference/api/scripting): running a packaged, self-contained function in `MAIN` and returning its serializable result through Chrome.

`runtime.js` is an independently written, focused adapter using these observable interfaces. It does not bundle either full library or load JavaScript from a CDN. It prefers native local database paging, falls back to the chat's earlier-message loader, and can use the documented WPP read API if that runtime is already present. It never calls send, delete, archive, mark-read or media-download operations. No messaging control APIs are exposed through the extension.

WhatsApp's runtime APIs are unofficial and may change. Capability diagnostics show which interfaces were actually found. Tests exercise Chrome's real MAIN-world bridge and synthetic model stores, not a live WhatsApp account. Product feature claims and fixture tests are not proof of live compatibility or complete server history.
