/* Small, replaceable DOM adapter. Structural fallbacks avoid generated CSS classes. */
(function(root) {
  const clean = s => (s || '').normalize('NFC').replace(/[\u200b-\u200f\u061c\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim();
  const visible = e => !!e && e.getClientRects().length > 0 && getComputedStyle(e).visibility !== 'hidden';
  function main() {
    const direct=[...document.querySelectorAll('#main,[data-testid="conversation-panel-wrapper"],[data-testid="conversation-panel"]')].filter(visible);
    const withHeader=direct.find(e=>e.querySelector('header'));
    if(withHeader)return withHeader;
    const side=sidebar();
    for(const candidate of direct){
      for(let p=candidate.parentElement;p&&p!==document.body;p=p.parentElement){
        if(p.contains(side))break;
        if(p.querySelector('header')&&visible(p))return p;
      }
    }
    const panels=[...document.querySelectorAll('main,[role="main"],section')].filter(e=>visible(e)&&!e.contains(side)&&e.querySelector('header')&&e.querySelector('[data-pre-plain-text],[data-id]'));
    if(panels.length)return panels.sort((a,b)=>a.contains(b)?1:b.contains(a)?-1:0)[0];
    // Locate a conversation-sized ancestor; never broaden extraction to body/sidebar.
    for(const anchor of document.querySelectorAll('[data-pre-plain-text]')){
      if(side?.contains(anchor))continue;
      for(let p=anchor.parentElement;p&&p!==document.body;p=p.parentElement){
        if(p.contains(side))break;
        if(p.querySelector('header')&&visible(p))return p;
      }
    }
    return direct[0]||null;
  }
  const sidebar = () => document.querySelector('#pane-side') || document.querySelector('[data-testid="chat-list"]') || document.querySelector('[aria-label="Chat list"]');
  function rows() {
    let list=[];
    for(const selector of ['[role="row"]','[data-testid="cell-frame-container"]','[role="listitem"]','[role="gridcell"]']){
      list=[...(sidebar()?.querySelectorAll(selector)||[])].filter(visible);if(list.length)break;
    }
    return list.filter(e => !list.some(other => other !== e && other.contains(e))).map(row => {
      const title = row.querySelector('[data-testid="cell-frame-title"]') || [...row.querySelectorAll('span[title],[dir="auto"][title]')].find(visible);
      const titled=title?.matches('[title]')?title:title?.querySelector('[title]');
      const name=clean(titled?.getAttribute('title')||title?.textContent||row.getAttribute('aria-label')).replace(/^\d[\d,.]*\s+unread\s+messages?\s+/i,'').trim();
      return name ? {name,row,title:titled||title} : null;
    }).filter(Boolean);
  }
  function headerName() {
    const header = main()?.querySelector('header');
    const explicit=header?.querySelector('[data-testid="conversation-info-header-chat-title"],[data-testid="conversation-title"]');
    if(explicit&&visible(explicit))return clean(explicit.getAttribute('title')||explicit.textContent);
    const candidates=[...header?.querySelectorAll('span[title],[dir="auto"][title]')||[]].filter(e=>visible(e)&&!e.closest('button,[data-testid="participant-list"]'));
    const meaningful=candidates.find(e=>{const t=clean(e.getAttribute('title')).toLowerCase();return t&&!['profile details','click here for contact info','profile photo','group info'].includes(t)&&!t.startsWith('wds-');});
    return clean(meaningful?.getAttribute('title')||[...header?.querySelectorAll('span[dir="auto"]')||[]].find(e=>visible(e)&&!e.closest('button,[data-testid="participant-list"]'))?.textContent);
  }
  const headerMatches=name=>headerName()===clean(name);
  function activationTargets(row){
    return [...new Set([row.querySelector('[data-testid="cell-frame-title"] span[title]'),row.querySelector('[data-testid="cell-frame-title"]'),row.querySelector('span[title]'),row.querySelector('[data-testid="cell-frame-container"]'),row.querySelector('[role="gridcell"]'),row])].filter(e=>e&&visible(e));
  }
  function activate(target){
    target.scrollIntoView({block:'nearest',inline:'nearest'});
    const box=target.getBoundingClientRect(),options={bubbles:true,cancelable:true,composed:true,button:0,clientX:box.left+box.width/2,clientY:box.top+box.height/2};
    target.focus({preventScroll:true});
    if(typeof PointerEvent!=='undefined')target.dispatchEvent(new PointerEvent('pointerdown',{...options,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:1}));
    target.dispatchEvent(new MouseEvent('mousedown',{...options,buttons:1}));
    if(typeof PointerEvent!=='undefined')target.dispatchEvent(new PointerEvent('pointerup',{...options,pointerId:1,pointerType:'mouse',isPrimary:true,buttons:0}));
    target.dispatchEvent(new MouseEvent('mouseup',{...options,buttons:0}));target.click();
  }
  function diagnostics(name){
    const panel=main();return {mainFound:!!panel,headerFound:!!panel?.querySelector('header'),headerMatched:headerMatches(name),observedHeader:headerName().slice(0,140),visibleRows:rows().length,exactRows:rows().filter(r=>r.name===clean(name)).length,messageMetadata:metadata().length,messageContainers:panel?.querySelectorAll('[data-id],.message-in,.message-out').length||0,online:navigator.onLine};
  }
  function scroller(container, anchor) {
    if (!container) return null;
    const candidates = [];
    for (let e = anchor?.parentElement; e && container.contains(e); e = e.parentElement) {
      if (e.clientHeight > 80 && /auto|scroll/.test(getComputedStyle(e).overflowY)) candidates.push(e);
    }
    if (candidates.length) return candidates[0];
    return [container,...container.querySelectorAll('div')].filter(e => visible(e) && e.clientHeight > 80 && /auto|scroll/.test(getComputedStyle(e).overflowY)).sort((a,b) => (b.scrollHeight-b.clientHeight)-(a.scrollHeight-a.clientHeight))[0] || null;
  }
  const reverse = e => getComputedStyle(e).flexDirection === 'column-reverse';
  const atBottom = e => reverse(e) ? e.scrollTop >= -3 : e.scrollTop+e.clientHeight >= e.scrollHeight-3;
  const atTop = e => reverse(e) ? e.scrollTop <= -(e.scrollHeight-e.clientHeight)+3 : e.scrollTop <= 3;
  function searchBox() {
    const scope = document.querySelector('#side') || sidebar()?.parentElement;
    return [...scope?.querySelectorAll('[contenteditable="true"][role="textbox"],input[type="text"],input[type="search"]') || []].filter(visible).find(e => !main()?.contains(e));
  }
  function setSearch(value) {
    const e = searchBox(); if (!e) throw new Error('Chat search control not found. Open the Chats view.');
    e.focus();
    if (e instanceof HTMLInputElement) {
      Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,value);
    } else {
      const selection = getSelection(), range = document.createRange();
      range.selectNodeContents(e); selection.removeAllRanges(); selection.addRange(range);
      if (!document.execCommand('insertText',false,value)) { e.textContent = value; }
    }
    e.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));
    return e;
  }
  const metadata = () => [...main()?.querySelectorAll('[data-pre-plain-text]') || []].filter(e => !e.parentElement.closest('[data-pre-plain-text]'));
  function messageText(node) {
    if(node.nodeType===Node.TEXT_NODE)return node.textContent;
    if(node.nodeType!==Node.ELEMENT_NODE)return '';
    if(node.tagName==='IMG')return node.getAttribute('alt')||node.getAttribute('aria-label')||'';
    if(node.tagName==='BR')return '\n';
    const text=[...node.childNodes].map(messageText).join('');
    return /^(DIV|P)$/.test(node.tagName)?text+'\n':text;
  }
  function read(order) {
    const messages = [], warnings = new Set(), identities = new Set(); let unparsed = 0;
    for (const el of metadata()) {
      const meta = el.getAttribute('data-pre-plain-text'), parsed = ExporterCore.parseMeta(meta,order);
      if (!parsed) { unparsed++; continue; }
      const bubble = el.closest('[data-id],.message-in,.message-out') || el.parentElement;
      const nodes = [...bubble.querySelectorAll('.selectable-text.copyable-text,[data-testid="msg-text"]')].filter(n => !n.closest('[data-testid*="quoted"],[data-testid*="reply-context"]'));
      const text = nodes.filter(n => !nodes.some(p => p !== n && p.contains(n))).map(messageText).join('\n').trim();
      const attachments = new Set();
      for (const n of bubble.querySelectorAll('[download],[title],[aria-label],[data-testid*="document"],[data-testid*="filename"]')) {
        // Do not infer files from ordinary message bodies or quoted messages.
        if (n.closest('.selectable-text,[data-testid="msg-text"],[data-testid*="quoted"]')) continue;
        for (const value of [n.getAttribute('download'),n.getAttribute('title'),n.getAttribute('aria-label'),n.matches('[data-testid*="document"],[data-testid*="filename"]') ? n.textContent : null]) {
          const file = clean(value).replace(/^(Download|Open|Save)\s+/i,'');
          if (file && file.length < 240 && (/\.[\p{L}\p{N}]{1,16}$/u.test(file) || value === n.getAttribute('download') || n.matches('[data-testid*="filename"]'))) attachments.add(file);
        }
      }
      if (!attachments.size && bubble.querySelector('img[src^="blob:"],video,audio,[data-testid*="document"],[data-icon*="audio"],[data-icon*="document"],[data-icon*="video"],[data-icon*="image"]')) attachments.add('Media: original filename not exposed by WhatsApp');
      const id = bubble.getAttribute('data-id') || el.closest('[data-id]')?.getAttribute('data-id');
      const identity = ExporterCore.identity(id); if (identity) identities.add(identity);
      if (!id) warnings.add('Missing stable IDs; identical messages in the same second may merge.');
      messages.push({...parsed,text,attachments:[...attachments],key:id || JSON.stringify([meta,text,[...attachments]])});
    }
    if (unparsed) warnings.add('Unparsed displayed metadata: '+unparsed+'. Coverage cannot be confirmed.');
    if (identities.size > 1) throw new Error('Messages from multiple chat identities detected. Extraction stopped.');
    return {messages,warnings:[...warnings],unparsed,identity:[...identities][0] || null};
  }
  root.ExportDOM = {clean,visible,main,sidebar,rows,headerName,headerMatches,activationTargets,activate,diagnostics,scroller,reverse,atTop,atBottom,searchBox,setSearch,metadata,read};
})(globalThis);
