const $=id=>document.getElementById(id);
let discovered=[],selected=new Set(),snapshot=null,rendering=false,renderAgain=false;
let discovering=false;
let startupText='';
function notify(message,error=false){
  $('notice').textContent=message;
  $('actionStatus').textContent=message;
  $('actionStatus').classList.toggle('error',error);
}
function startup(message){startupText=message;notify(message);updateSummary();}
async function bounded(promise,label,ms=20000){
  let timer;
  try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`${label} timed out. Check WhatsApp Web and refresh its tab if needed. Saved jobs remain available; check progress before retrying.`)),ms);})]);}
  finally{clearTimeout(timer);}
}
const statusLabel=s=>({'running':'Export running','paused':'Paused','interrupted':'Interrupted — resume to continue','needs-review':'Finished with partial results','finished':'Export finished','pending':'Waiting to start'}[s]||'Ready');
function updateSummary(){
  const job=snapshot?.job,chats=job?.chats||[];
  const reached=chats.filter(c=>c.status==='range-reached').length,partial=chats.filter(c=>c.status==='partial').length;
  const processed=reached+partial,total=chats.length,percent=total?Math.round(processed/total*100):0;
  $('runStatus').textContent=startupText|| (discovering?'Finding chats…':statusLabel(job?.status));
  $('progressPercent').textContent=startupText?'Starting…':discovering?'Scanning…':`${percent}%`;
  $('overallProgress').max=total||1;
  if(discovering||startupText)$('overallProgress').removeAttribute('value');else $('overallProgress').value=processed;
  $('progressSummary').textContent=total?`${processed} of ${total} chats scanned · ${reached} reached the date boundary · ${partial} partial`:'No saved export.';
  $('messageTotal').textContent=chats.reduce((sum,c)=>sum+(c.count||0),0).toLocaleString();
  $('rangeTotal').textContent=reached;$('partialTotal').textContent=partial;$('remainingTotal').textContent=total-processed;
  const current=job?.owner && (chats.find(c=>c.id===job.currentChatId)||chats.find(c=>['running','retrying'].includes(c.status)));
  $('currentWork').hidden=!current;
  if(current){
    $('currentChat').textContent=`Chat ${chats.indexOf(current)+1} of ${total}: ${current.name}`;
    $('currentActivity').textContent=current.activity||current.reason||'Starting…';
    $('currentDetails').textContent=`${(current.count||0).toLocaleString()} messages saved · ${current.steps||0} ${current.engine==='data'?'message batches':'history scans'}${current.oldestSeen?' · Oldest date seen: '+current.oldestSeen:''}`;
  }
  const saved=job?.updatedAt && Date.parse(job.updatedAt),age=saved?Math.max(0,Math.floor((Date.now()-saved)/1000)):null;
  $('lastSaved').textContent=age===null?'Progress is saved automatically after every scanned batch.':`Last checkpoint: ${new Date(saved).toLocaleTimeString()} (${age<60?age+' seconds':Math.floor(age/60)+' minutes'} ago).${job.status==='running'&&age>=30?' Waiting for WhatsApp to load or the background tab to respond.':''}`;
}
async function rpc(msg) {
  const result=await bounded(chrome.runtime.sendMessage(msg),`Extension ${msg.type}`,msg.type==='download'?60000:20000);
  if(!result||result.error)throw new Error(result?.error||'Extension did not respond. Reload the extension.');
  return result;
}
async function tab() {
  const tabs=await bounded(chrome.tabs.query({url:'https://web.whatsapp.com/*'}),'Finding WhatsApp tab',10000);
  if(tabs.length!==1)throw new Error('Open exactly one WhatsApp Web tab.');
  return tabs[0];
}
async function send(type,extra={}) {
  const target=await tab();
  try {
    const result=await bounded(chrome.tabs.sendMessage(target.id,{type,...extra}),`WhatsApp ${type}`,type==='discover'?900000:type==='ping'?10000:20000);
    if(result?.error)throw new Error(result.error);
    if(!result)throw new Error('No response from WhatsApp tab.');
    return result;
  }catch(e){
    if(/Receiving end|connection|port closed/i.test(e.message))throw new Error('Refresh WhatsApp Web after loading/updating the extension, then retry. Saved work remains available.');
    throw e;
  }
}
function action(id,fn) {
  $(id).onclick=async()=>{
    $(id).disabled=true;
    const text=$(id).textContent;
    if(id==='startJob')$(id).textContent='Starting…';
    try{await fn();}catch(e){notify(e.message,true);$('actionStatus').scrollIntoView({block:'nearest'});}
    finally{$(id).disabled=false;$(id).textContent=text;}
  };
}
function renderChats() {
  const filter=$('filter').value.toLocaleLowerCase();
  $('chats').replaceChildren();
  for(const chat of discovered.filter(c=>c.name.toLocaleLowerCase().includes(filter))){
    const label=document.createElement('label'),input=document.createElement('input');
    const key=chat.remoteId||chat.name;
    input.type='checkbox';input.checked=selected.has(key);input.disabled=!!chat.ambiguous;
    input.onchange=()=>input.checked?selected.add(key):selected.delete(key);
    const duplicate=discovered.filter(c=>c.name===chat.name).length>1;
    label.append(input,document.createTextNode(chat.name+(duplicate&&chat.remoteId?' — '+chat.remoteId:'')+(chat.archived?' (archived)':'')+(chat.ambiguous?' (duplicate name; rename before exporting)':'')));$('chats').append(label);
  }
}
$('filter').oninput=renderChats;
action('selectAll',async()=>{const f=$('filter').value.toLocaleLowerCase();discovered.filter(c=>!c.ambiguous&&c.name.toLocaleLowerCase().includes(f)).forEach(c=>selected.add(c.remoteId||c.name));renderChats();});
action('selectNone',async()=>{selected.clear();renderChats();});
action('discover',async()=>{
  $('notice').textContent='Scanning the chat list…';
  discovering=true;updateSummary();
  try{
    const result=await send('discover');discovered=result.chats;
    await chrome.storage.local.set({discovered});renderChats();
    $('notice').textContent=`${discovered.length} names found. ${result.warning||''}`;
  }finally{discovering=false;updateSummary();}
});
action('startJob',async()=>{
  try{
    startup('Checking selected chats and dates…');
    const chats=discovered.filter(c=>selected.has(c.remoteId||c.name)&&!c.ambiguous);
    if(!chats.length)throw new Error('Select at least one chat using its checkbox, then click Start new export.');
    if(!$('start').value||!$('end').value)throw new Error('Choose both From and Through dates before starting.');
    if(!$('start').checkValidity()||!$('end').checkValidity()||$('start').value>$('end').value)throw new Error('Choose a valid date range: From must be on or before Through.');
    startup(`Connecting to WhatsApp Web for ${chats.length} selected chat(s)…`);
    const initial=await send('ping');
    startup('Preparing the exporter and stopping any previous scan…');
    await rpc({type:'pause'});
    if(initial.busy)await send('stop');
    const deadline=Date.now()+15000;let idle=false;
    while(Date.now()<deadline){const r=await send('ping');if(!r.busy){idle=true;break;}await new Promise(r=>setTimeout(r,250));}
    if(!idle)throw new Error('The previous scan is still stopping. Wait a moment and retry, or refresh WhatsApp Web. Your saved work is retained.');
    const job={id:crypto.randomUUID(),engine:$('engine').value,accountId:chats[0].sourceAccountId||null,account:$('account').value.trim()||'Default account',start:$('start').value,end:$('end').value,order:$('order').value,status:'paused',createdAt:new Date().toISOString(),chats:chats.map(c=>({name:c.name,remoteId:c.remoteId||null,sourceAccountId:c.sourceAccountId||null,id:crypto.randomUUID(),status:'pending',count:0}))};
    startup(`Saving export settings for ${chats.length} chat(s)…`);
    await rpc({type:'create',job});await render();
    startup(`Starting extraction — first chat: ${chats[0].name}…`);
    await send('resume',{jobId:job.id});
    notify(`Export started for ${chats.length} chat(s). Processing ${chats[0].name}. Live progress is shown below.`);
    $('liveProgress').scrollIntoView({block:'nearest'});await render();
  }finally{startupText='';updateSummary();}
});
action('pause',async()=>{notify('Pausing extraction…');await rpc({type:'pause'});notify('Paused. Successfully committed messages are saved.');await render();});
action('resume',async()=>{
  const {job}=await rpc({type:'snapshot'});if(!job)throw new Error('Start an export first.');
  if(!confirm(`Verify WhatsApp Web is signed into ${job.account}. Resume ${job.start} through ${job.end}?`))return;
  notify('Connecting to WhatsApp Web to resume the saved export…');
  await send('resume',{jobId:job.id});notify('Export resumed. Live progress is shown below.');await render();
});
$('history').onchange=async()=>{
  try{await rpc({type:'activate',jobId:$('history').value});await render();}catch(e){$('notice').textContent=e.message;}
};
async function download(chatId,format='txt') {
  const result=await rpc({type:'download',jobId:snapshot.job.id,chatId,format});
  $('notice').textContent=`Download requested (#${result.downloadId}). Check Chrome Downloads for completion.`;
}
action('downloadAll',async()=>{if(snapshot?.job)for(const c of snapshot.job.chats)await download(c.id);});
action('diagnostics',async()=>{
  if(!snapshot?.job)throw new Error('No saved job.');
  const {job}=snapshot;
  // No message bodies, attachment payloads or chat identity fields in diagnostics.
  const data={version:chrome.runtime.getManifest().version,engine:job.engine||'data',status:job.status,reason:job.reason,start:job.start,end:job.end,order:job.order,updatedAt:job.updatedAt,chats:job.chats.map((c,i)=>({number:i+1,status:c.status,count:c.count,steps:c.steps,oldestSeen:c.oldestSeen,resolvedOrder:c.resolvedOrder,warnings:c.warnings,reason:c.reason,navigation:c.navigation,capabilities:c.capabilities,readMethod:c.readMethod,downloadError:c.downloadError}))};
  const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));
  try{await chrome.downloads.download({url,filename:'WhatsApp-exports/diagnostics.json',saveAs:false});}finally{setTimeout(()=>URL.revokeObjectURL(url),60000);}
});
async function render() {
  if(rendering){renderAgain=true;return;}
  rendering=true;
  try {
    do{
      renderAgain=false;snapshot=await rpc({type:'snapshot'});
      const {job,jobs}=snapshot;
      updateSummary();
      $('history').replaceChildren(...jobs.map(j=>{const option=document.createElement('option');option.value=j.id;option.textContent=`${j.account}: ${j.start} – ${j.end} (${j.status})`;option.selected=j.id===job?.id;return option;}));
      $('progress').replaceChildren();
      if(!job){$('progress').textContent='No saved export.';continue;}
      const title=document.createElement('p');title.textContent=`${job.account}: ${job.start} – ${job.end} · ${job.status}. ${job.reason||''}`;$('progress').append(title);
      for(const chat of job.chats){
        const p=document.createElement('article'),heading=document.createElement('h3'),detail=document.createElement('p');
        p.className='chat-card'+(job.owner&&job.currentChatId===chat.id?' current':'');
        heading.textContent=`${job.chats.indexOf(chat)+1}. ${chat.name}`;
        const status=document.createElement('p');status.className='chat-status';status.textContent=chat.status.replaceAll('-',' ');
        const fileStatus=chat.download?.state==='complete'?`File saved (${chat.status==='range-reached'?'date boundary reached':chat.status+' extraction'}; ${chat.count||0} messages).`:chat.download?'Download: '+chat.download.state+' '+(chat.download.error||''):'';
        detail.textContent=`${(chat.count||0).toLocaleString()} messages saved · ${chat.steps||0} scans. ${chat.oldestSeen?'Oldest seen: '+chat.oldestSeen+'. ':''}${chat.reason||''} ${(chat.warnings||[]).join('; ')} ${chat.downloadError||''} ${fileStatus}`;
        p.append(heading,status,detail);
        for(const format of ['txt','json']){
          const button=document.createElement('button');button.textContent=`Download ${format.toUpperCase()}`;
          button.onclick=()=>download(chat.id,format).catch(e=>{$('notice').textContent=e.message;});p.append(button);
        }$('progress').append(p);
      }
    }while(renderAgain);
  }catch(e){$('notice').textContent=e.message;}finally{rendering=false;}
}
chrome.runtime.onMessage.addListener(msg=>{if(msg.type==='progressChanged')render();});
setInterval(updateSummary,1000);
(async()=>{
  const saved=await chrome.storage.local.get(['discovered']);discovered=saved.discovered||[];renderChats();
  const today=new Date(),pad=n=>String(n).padStart(2,'0');
  $('end').value=`${today.getFullYear()}-${pad(today.getMonth()+1)}-${pad(today.getDate())}`;await render();
})().catch(e=>{$('notice').textContent=e.message;});
