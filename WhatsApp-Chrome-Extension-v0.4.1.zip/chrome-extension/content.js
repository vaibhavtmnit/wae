(() => {
  const D = ExportDOM;
  let busy = false, stopped = false;
  class Halt extends Error {}
  const check = () => { if (stopped) throw new Halt('Paused'); };
  async function sleep(ms) {
    const until = Date.now()+ms;
    while (Date.now()<until) { check(); await new Promise(r => setTimeout(r,Math.min(150,until-Date.now()))); }
  }
  async function rpc(msg) {
    const result = await chrome.runtime.sendMessage(msg);
    if (!result || result.error) throw new Error(result?.error || 'Extension did not respond. Reload it and resume.');
    return result;
  }
  async function waitFor(fn, timeout=15000, stage='WhatsApp readiness') {
    const until = Date.now()+timeout;
    while (Date.now()<until) { check(); const result = fn(); if (result) return result; await sleep(200); }
    throw new Error(`${stage} timed out. Check connection, login and chat layout.`);
  }
  async function discoverDOM() {
    await waitFor(D.sidebar);
    D.setSearch(''); await sleep(500);
    const seen = new Map(); let previous='', stable=0, exhausted=false;
    let scroll = D.scroller(D.sidebar());
    if (scroll) {scroll.scrollTop=0; await sleep(500);}
    for (let step=0; step<1500; step++) {
      check();
      const rows=D.rows(), counts=new Map();
      rows.forEach(({name}) => counts.set(name,(counts.get(name)||0)+1));
      counts.forEach((count,name) => seen.set(name,{name,ambiguous:count>1 || seen.get(name)?.ambiguous}));
      scroll=D.scroller(D.sidebar());
      const signature=rows.map(r=>r.name).join('|');
      const bottom=!scroll || D.atBottom(scroll);
      stable=signature===previous && bottom ? stable+1 : 0;
      if(stable>=5){exhausted=true;break;}
      previous=signature;
      if(scroll) scroll.scrollTop+=Math.max(80,scroll.clientHeight*.5);
      await sleep(stable ? 700 : 250);
    }
    if(scroll) scroll.scrollTop=0;
    return {chats:[...seen.values()],warning:(exhausted?'':'Scan limit reached; list may be incomplete. ')+'Archived/locked/filtered chats may be absent. Duplicate names cannot be selected safely.'};
  }
  async function discover(){
    let failure='';
    try{
      const result=await rpc({type:'discoverData'});
      if(result.chats.length)return {...result,warning:'Chats read from WhatsApp data store, including available archived chats. Stable IDs distinguish duplicate names.'};
      failure='The chat data store is still empty.';
    }catch(e){failure=e.message;}
    const result=await discoverDOM();
    return {...result,warning:`Sidebar discovery used. Data-store discovery: ${failure} ${result.warning}`};
  }
  async function findChat(name) {
    // First scan exact rows; only use search when the target is virtualized away.
    let matches=D.rows().filter(r=>r.name===name);
    if(matches.length>1) throw new Error('Duplicate chat name: '+name);
    if(matches.length===1) return matches[0].row;
    D.setSearch(name);
    let signature='', stable=0;
    return waitFor(() => {
      const rows=D.rows(), next=rows.map(r=>r.name).join('|');
      stable=next===signature ? stable+1 : 0; signature=next;
      matches=rows.filter(r=>r.name===name);
      if(matches.length>1) throw new Error('Duplicate chat name: '+name);
      return stable>=3 && matches.length===1 ? matches[0].row : null;
    },20000,`Finding an exact chat row for “${name}”`);
  }
  async function openChat(chat,report) {
    const phase=async(stage,reason)=>report({reason,navigation:{stage,...D.diagnostics(chat.name)}});
    await phase('sidebar','Waiting for the WhatsApp chat list');
    if(!D.headerMatches(chat.name)){
      await waitFor(D.sidebar,15000,'Waiting for the chat list');
      await phase('find-chat','Locating the selected chat in WhatsApp');
      let row=await findChat(D.clean(chat.name));
      let opened=false;
      // React handlers may live on an inner title/cell rather than its role=row wrapper.
      const targets=D.activationTargets(row);
      for(let index=0;index<targets.length;index++){
        check();
        if(!row.isConnected){row=await findChat(D.clean(chat.name));}
        const target=targets[index].isConnected?targets[index]:D.activationTargets(row)[index];
        if(!target)continue;
        await phase('activate-chat',`Opening chat: trying clickable element ${index+1}/${targets.length}`);
        D.activate(target);
        const until=Date.now()+1800;
        do{if(D.headerMatches(chat.name)){opened=true;break;}await sleep(150);}while(Date.now()<until);
        if(opened)break;
      }
      if(!opened){
        const diagnostic=D.diagnostics(chat.name);
        await report({navigation:{stage:'header-not-confirmed',...diagnostic}});
        throw new Error(`Chat selection could not be confirmed after trying title, cell and row clicks. ${diagnostic.headerFound?'The visible conversation header did not match the selected chat.':'No supported conversation header was found.'} Open the selected chat manually in WhatsApp Web, then Resume unfinished chats.`);
      }
    }
    await phase('message-metadata','Chat header confirmed; waiting for readable messages');
    try{await waitFor(()=>D.headerMatches(chat.name)&&D.metadata().length,15000,'Loading dated message elements in the selected chat');}
    catch(e){
      const diagnostic=D.diagnostics(chat.name);
      await report({navigation:{stage:'messages-unavailable',...diagnostic}});
      if(!D.headerMatches(chat.name))throw new Halt('The active chat changed while waiting for messages. Open the selected chat and resume.');
      if(diagnostic.messageContainers&&!diagnostic.messageMetadata)throw new Halt('The chat opened, but its messages use an unsupported date-metadata layout. No history was claimed as extracted. Download diagnostics to identify this layout.');
      throw new Error('The chat header was confirmed, but no dated messages loaded. The chat may be empty, still syncing, or using an unsupported layout. Open it manually, wait for messages, then resume.');
    }
    await phase('ready','Chat opened and dated messages detected');await sleep(250);
  }
  async function latest(chat) {
    // Establish the newest edge before accepting a date boundary on an old viewport.
    let stable=0, previous='';
    for(let i=0;i<35;i++) {
      check();
      if(!D.headerMatches(chat.name)) throw new Halt('Active chat changed. Resume after restoring WhatsApp.');
      const scroll=D.scroller(D.main(),D.metadata()[0]);
      if(!scroll) return false;
      const jump=D.main().querySelector('[data-testid="scroll-to-bottom"], [data-icon="down"]');
      if(jump && D.visible(jump)) (jump.closest('button,[role="button"]')||jump).click();
      scroll.scrollTop=D.reverse(scroll)?0:scroll.scrollHeight;
      await sleep(300);
      const signature=D.metadata().map(e=>e.getAttribute('data-pre-plain-text')).join('|');
      stable=D.atBottom(scroll) && signature && signature===previous ? stable+1 : 0;
      if(stable>=3) return true;
      previous=signature;
    }
    return false;
  }
  async function extractDOM(job,chat,token) {
    let patch={status:'running',activity:null,reason:'Opening chat',warnings:[...(chat.warnings||[])],attempts:(chat.attempts||0)+1};
    const warnings=new Set(patch.warnings);
    warnings.add('Web history completeness is unverified; system events without message metadata may be omitted.');
    let lastSave=0;
    const save=async (extra={},messages=[]) => {
      patch={...patch,...extra,warnings:[...warnings]};
      await rpc({type:'checkpoint',jobId:job.id,chatId:chat.id,token,patch,messages}); lastSave=Date.now();
    };
    await save();
    let lastFailure='';
    for(let attempt=0;attempt<3;attempt++) {
      try {
        if(attempt) {await save({status:'retrying',reason:`Retry ${attempt}/2: ${lastFailure}`});await sleep(1000*2**attempt);}
        await openChat(chat,save);
        await save({status:'running',reason:'Checking the newest messages before scanning history'});
        const newest=await latest(chat);
        if(!newest) warnings.add('Could not verify the newest edge; coverage remains partial.');
        let stable=0, previous='', previousKeys=null, lastPos=null, lostOverlap=0, fraction=.4, oldest=null;
        let parseErrors=false, gaps=false, order=job.order;
        for(let step=0;step<15000;step++) {
          check();
          if(!D.headerMatches(chat.name)) throw new Halt('Active chat changed. Extraction paused to avoid mixing chats.');
          if(!navigator.onLine) {await save({status:'retrying',reason:'Offline; waiting for connection'});await waitFor(()=>navigator.onLine,45000);}
          if(order==='auto') {
            order=ExporterCore.inferOrder(D.metadata().map(e=>e.getAttribute('data-pre-plain-text')));
            if(!order) throw new Halt('Dates are ambiguous. Choose day/month or month/day explicitly and start a new job.');
          }
          const batch=D.read(order);
          if(chat.remoteId&&batch.identity&&chat.remoteId!==batch.identity)throw new Halt('The visible conversation ID differs from the selected chat. No records from it were saved.');
          if(chat.identity && batch.identity && chat.identity!==batch.identity) throw new Halt('Saved chat identity differs from this conversation/account.');
          if(patch.identity && batch.identity && patch.identity!==batch.identity) throw new Halt('Conversation identity changed while scanning.');
          batch.warnings.forEach(w=>warnings.add(w)); parseErrors ||= batch.unparsed>0;
          const keys=new Set(batch.messages.map(m=>m.key));
          const scroll=D.scroller(D.main(),D.metadata()[0]);
          if(previousKeys?.size && keys.size && ![...keys].some(k=>previousKeys.has(k))) {
            lostOverlap++;
            if(lostOverlap<=3 && scroll && lastPos!==null) {
              // A virtualized page jumped over the overlap. Return to the prior viewport
              // and retry a smaller scroll before accepting coverage.
              await save({reason:'Checking a possible gap; retrying a smaller scroll'});
              fraction=Math.max(.08,fraction/2); scroll.scrollTop=lastPos; await sleep(600);
              scroll.scrollTop-=Math.max(40,scroll.clientHeight*fraction); await sleep(700); continue;
            }
            gaps=true; warnings.add('A gap between rendered batches could not be ruled out.');
          } else lostOverlap=0;
          const dates=batch.messages.map(m=>m.date).sort();
          if(dates[0]) oldest=!oldest||dates[0]<oldest?dates[0]:oldest;
          await save({status:'running',reason:'Reading older messages',identity:batch.identity||patch.identity||chat.identity,steps:step+1,oldestSeen:oldest,resolvedOrder:order},batch.messages);
          if(batch.messages.length && batch.messages.every(m=>m.date<job.start)) {
            await save({status:newest&&!gaps&&!parseErrors?'range-reached':'partial',reason:newest&&!gaps&&!parseErrors?'Reached messages before the start date; rendered coverage established.':'Reached date boundary, but warnings prevent confirming coverage.'});return;
          }
          if(!scroll) {await save({status:'partial',reason:'Message scroller unavailable. Only rendered messages were saved.'});return;}
          const signature=[...keys].join('|');
          stable=signature===previous ? stable+1:0; previous=signature;
          if(stable>=12) {await save({status:'partial',reason:'Older history stopped loading after adaptive retries. Resume later to retry.'});return;}
          previousKeys=keys.size?keys:previousKeys; lastPos=scroll.scrollTop;
          scroll.scrollTop=Math.max(D.reverse(scroll)?-(scroll.scrollHeight-scroll.clientHeight):0,scroll.scrollTop-Math.max(40,scroll.clientHeight*fraction));
          // Wait for the DOM to settle, with a longer backoff when history stalls.
          const until=Date.now()+Math.min(6000,stable?700*2**Math.min(stable,3):1400);
          let signatureAfter='',quiet=0;
          do {
            await sleep(200);
            const now=D.metadata().map(e=>e.getAttribute('data-pre-plain-text')).join('|');
            quiet=now===signatureAfter?quiet+1:0;signatureAfter=now;
            if(!stable&&quiet>=2&&now!==signature) break;
            if(Date.now()-lastSave>20000) await save({reason:'Waiting for older messages'});
          }while(Date.now()<until);
        }
        await save({status:'partial',reason:'Safety scan limit reached; resume to retry.'});return;
      }catch(e) {
        if(stopped) throw e;
        if(e instanceof Halt) {await save({status:'partial',reason:e.message});throw e;}
        if(/ownership|expired|paused|identity/i.test(e.message)) throw e;
        if(attempt===2) {await save({status:'partial',reason:e.message});return;}
        lastFailure=e.message;
        warnings.add('Earlier attempt failed: '+e.message);
      }
    }
  }
  async function extractData(job,chat,token){
    let patch={engine:'data',status:'running',activity:null,reason:'Connecting to WhatsApp chat data store',attempts:(chat.attempts||0)+1};
    const warnings=new Set((chat.warnings||[]).filter(w=>!/^Web history|^Recovered temporary failure: WhatsApp did not/.test(w)));
    warnings.add('Only history available to this WhatsApp Web device can be exported; server completeness is unverified.');
    let accountId=job.accountId||chat.sourceAccountId||null;
    const save=async(extra={},messages=[])=>{
      patch={...patch,...extra,warnings:[...warnings]};
      await rpc({type:'checkpoint',jobId:job.id,chatId:chat.id,token,accountId,patch,messages});
    };
    const read=(command,args={})=>rpc({type:'readData',jobId:job.id,chatId:chat.id,token,command,args});
    await save();
    let cursor=chat.engine==='data'?chat.cursor||null:null,steps=chat.steps||0,errors=!!chat.dataHadErrors,lastFailure='';
    for(let attempt=0;attempt<3;attempt++){
      try{
        if(attempt){await save({status:'retrying',reason:`Retry ${attempt}/2: ${lastFailure}`});await sleep(1000*2**attempt);}
        const resolved=await read('resolve',{remoteId:chat.remoteId||patch.remoteId});
        accountId=resolved.accountId||accountId;
        await save({remoteId:resolved.remoteId,identity:resolved.remoteId,capabilities:resolved.capabilities,reason:'Chat ID verified; reading messages directly (no chat clicks or scrolling)'});
        let refreshNewest=!!cursor,catchupCursor=null,stalls=0;
        const resumeBoundary=chat.newestTimestamp||cursor?.timestamp;
        let newestTimestamp=chat.newestTimestamp||null;
        for(let page=0;page<15000;page++){
          check();
          await save({status:'running',activity:null,reason:refreshNewest?'Checking newest messages before continuing the saved cursor':'Loading the next message batch from WhatsApp data store'});
          const batch=await read('page',{remoteId:resolved.remoteId,cursor:refreshNewest?catchupCursor:cursor,limit:100});
          batch.warnings.forEach(w=>warnings.add(w));errors ||= batch.invalid>0;
          if(batch.accountId)accountId=batch.accountId;
          const messages=batch.messages;
          const previous=refreshNewest?catchupCursor:cursor;
          if(messages.length)newestTimestamp=Math.max(newestTimestamp||0,messages.at(-1).timestamp);
          if(!refreshNewest&&batch.nextCursor)cursor=batch.nextCursor;
          const oldest=messages[0]?.date;
          steps++;
          const caughtUp=refreshNewest&&messages.length&&messages[0].timestamp<=resumeBoundary;
          // During catch-up retain the old watermark until every newer page was saved.
          await save({status:'running',reason:`Read ${messages.length} message records using ${batch.method}`,cursor,newestTimestamp:refreshNewest&&!caughtUp?chat.newestTimestamp:newestTimestamp,steps,dataHadErrors:errors,oldestSeen:oldest&&(!patch.oldestSeen||oldest<patch.oldestSeen)?oldest:patch.oldestSeen||chat.oldestSeen,capabilities:batch.capabilities,readMethod:batch.method},messages);
          if(refreshNewest){
            catchupCursor=batch.nextCursor;
            if(caughtUp){refreshNewest=false;stalls=0;continue;}
            stalls=!messages.length||!catchupCursor||catchupCursor.key===previous?.key?stalls+1:0;
            if(stalls>=3){await save({status:'partial',reason:'Could not bridge newest messages to the saved checkpoint. Saved available records; resume later.'});return;}
            await sleep(150);continue;
          }
          if(messages.length&&messages.every(m=>m.date<job.start)){
            await save({status:errors?'partial':'range-reached',reason:errors?'Date boundary reached, but some records were unreadable.':'Read message history before the selected start date using data-store pagination.'});return;
          }
          if(!messages.length||!cursor||cursor.key===previous?.key){stalls++;await sleep(600*stalls);}
          else stalls=0;
          if(stalls>=3||batch.exhausted&&messages.length===0){
            await save({status:'partial',reason:'No older history was returned by WhatsApp. Saved available messages; full history is not confirmed.'});return;
          }
          await sleep(100);
        }
        await save({status:'partial',reason:'History batch limit reached; resume to continue from the saved cursor.'});return;
      }catch(e){
        if(stopped||/ownership|expired|paused/i.test(e.message))throw e;
        if(/account|different chat|Chat ID changed|unique data-store/i.test(e.message)){
          await save({status:'partial',reason:e.message});throw new Halt(e.message);
        }
        lastFailure=e.message;
        if(attempt===2){await save({status:'partial',reason:e.message});return;}
        warnings.add('Earlier data read failed: '+e.message);
      }
    }
  }
  async function run(jobId) {
    if(busy) throw new Error('A scan is already running in this tab.');
    busy=true;stopped=false;
    let job,token;
    try {
      ({job}=await rpc({type:'claim',jobId})); token=job.owner.token;
      // Claim is durable and fences other tabs before acknowledging the start.
    }catch(e){busy=false;throw e;}
    (async()=>{
      try {
        for(const chat of job.chats) {
          check();if(chat.status==='range-reached')continue;
          if(job.engine==='dom')await extractDOM(job,chat,token);else await extractData(job,chat,token);
          await rpc({type:'checkpoint',jobId:job.id,chatId:chat.id,token,patch:{activity:'Preparing automatic TXT download'}});
          try{await rpc({type:'download',jobId:job.id,chatId:chat.id});}
          catch(e){await rpc({type:'checkpoint',jobId:job.id,chatId:chat.id,token,patch:{downloadError:e.message}});}
        }
        await rpc({type:'finish',jobId:job.id,token});
      }catch(e){
        if(!stopped) {
          // Finish releases ownership even after a deliberate identity/parse halt.
          try{await rpc({type:'finish',jobId:job.id,token});}catch{}
          console.warn('Exporter stopped:',e.message);
        }
      }finally{busy=false;}
    })();
    return {ok:true};
  }
  chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
    if(sender.id!==chrome.runtime.id)return;
    if(!['ping','stop','discover','resume'].includes(msg.type))return;
    (async()=>{
      if(msg.type==='ping')return {ok:true,busy,version:2};
      if(msg.type==='stop'){stopped=true;return {ok:true};}
      if(msg.type==='resume')return run(msg.jobId);
      if(busy)throw new Error('Pause the current extraction before finding chats.');
      busy=true;stopped=false;try{return await discover();}finally{busy=false;}
    })().then(respond,e=>respond({error:e.message}));return true;
  });
})();
