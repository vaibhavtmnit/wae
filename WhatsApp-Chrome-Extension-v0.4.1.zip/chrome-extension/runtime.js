/* Self-contained MAIN-world reader. See SOURCES.md. Read/load only: no send/delete/seen calls.
 * Passed as a function to chrome.scripting, so all helpers must live inside it.
 */
async function readWhatsApp(command, args={}) {
  try {
  const value=(o,k)=>{try{return o?.[k]??o?.attributes?.[k]??o?.['__x_'+k]??o?.get?.(k);}catch{return undefined;}};
  const clean=s=>String(s||'').normalize('NFC').replace(/[\u200b-\u200f\u061c\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim();
  function serialized(id){
    if(typeof id==='string')return id;
    if(!id)return '';
    if(typeof id._serialized==='string')return id._serialized;
    try{const s=id.toString();if(s&&s!=='[object Object]')return s;}catch{}
    const cached=Object.values(id).find(v=>typeof v==='string'&&/^(true|false)_[^_]+_/.test(v));
    if(cached)return cached;
    if(id.remote&&id.id)return `${Boolean(id.fromMe)}_${serialized(id.remote)}_${id.id}${id.participant?'_'+serialized(id.participant):''}`;
    if(id.user&&id.server)return `${id.user}@${id.server}`;
    return '';
  }
  const models=c=>{if(!c)return [];if(Array.isArray(c))return c;if(typeof c.getModelsArray==='function')return c.getModelsArray();if(typeof c.toArray==='function')return c.toArray();return c.models||c._models||[];};
  function module(name){for(const loader of [globalThis.require,globalThis.importNamespace]){if(typeof loader==='function')try{const m=loader(name);if(m)return m;}catch{}}return null;}
  const collections=module('WAWebCollections')||{};
  const W=globalThis.WPP;
  const Chats=collections.Chat||module('WAWebChatCollection')?.ChatCollection||W?.whatsapp?.ChatStore||globalThis.Store?.Chat;
  const Msgs=collections.Msg||module('WAWebMsgCollection')?.MsgCollection||W?.whatsapp?.MsgStore||globalThis.Store?.Msg;
  const Contacts=collections.Contact||module('WAWebContactCollection')?.ContactCollection||W?.whatsapp?.ContactStore||globalThis.Store?.Contact;
  const prefs=module('WAWebUserPrefsMeUser')||W?.whatsapp?.UserPrefs;
  let accountId='';
  try{accountId=serialized(prefs?.getMaybeMeUser?.()||prefs?.getMaybeMePnUser?.()||W?.conn?.getMyUserId?.());}catch{}
  const load=module('WAWebChatLoadMessages');
  const query=module('WAWebDBMessageFindLocal');
  const version=String(globalThis.Debug?.VERSION||W?.version||'unknown');
  const capabilities={engine:'data',version,chatStore:!!Chats,messageStore:!!Msgs,accountDetected:!!accountId,loadEarlier:typeof load?.loadEarlierMsgs==='function',queryBefore:typeof query?.msgFindByDirection==='function'||typeof query?.msgFindQuery==='function',wpp:!!W?.chat?.getMessages};
  if(command==='probe')return {capabilities,accountId};
  if(!Chats)throw new Error('WhatsApp chat data store is not available yet. Keep WhatsApp signed in and wait for initial sync. No DOM extraction was substituted.');
  if(args.accountId&&accountId!==args.accountId)throw new Error('Signed-in account could not be verified against this saved export. Restore the original account or start a separate export.');
  function contact(id){try{return Contacts?.get?.(id)||Contacts?.get?.(serialized(id));}catch{return null;}}
  const contactName=c=>clean(value(c,'name')||value(c,'pushname')||value(c,'shortName')||value(c,'formattedName'));
  function chatName(c){return clean(value(c,'formattedTitle')||value(c,'name')||value(c,'groupMetadata')?.subject||contactName(value(c,'contact'))||contactName(contact(value(c,'id')))||serialized(value(c,'id')));}
  function summary(c){const remoteId=serialized(value(c,'id'));return {name:chatName(c),remoteId,sourceAccountId:accountId||null,archived:!!value(c,'archive'),engine:'data'};}
  if(command==='discover')return {chats:models(Chats).map(summary).filter(c=>c.remoteId),accountId,capabilities};
  let chat;
  if(args.remoteId){
    chat=models(Chats).find(c=>serialized(value(c,'id'))===args.remoteId);
    if(!chat)try{chat=Chats.get?.(args.remoteId);}catch{}
    if(!chat&&typeof Chats.find==='function'){
      const factory=module('WAWebWidFactory');
      chat=await Chats.find(factory?.createWid?factory.createWid(args.remoteId):args.remoteId);
    }
    if(!chat||serialized(value(chat,'id'))!==args.remoteId)throw new Error('The saved chat ID is not available in this account.');
  }else{
    const matches=models(Chats).filter(c=>chatName(c)===clean(args.name));
    if(matches.length!==1)throw new Error(`Cannot resolve saved chat name to a unique data-store ID (${matches.length} matches). Run Find chats again and start a new export using its stable chat ID.`);
    chat=matches[0];
  }
  const remoteId=serialized(value(chat,'id'));
  if(command==='resolve')return {...summary(chat),accountId,capabilities};
  if(command!=='page')throw new Error('Unsupported read command');
  const getTimestamp=m=>{let t=Number(value(m,'t')??value(m,'timestamp'));if(t>1e12)t/=1000;return Number.isFinite(t)&&t>0?t:null;};
  const key=m=>serialized(value(m,'id'));
  const pool=()=>{
    const local=models(value(chat,'msgs'));
    const global=models(Msgs).filter(m=>serialized(value(value(m,'id'),'remote'))===remoteId);
    return [...new Map([...local,...global].filter(m=>key(m)).map(m=>[key(m),m])).values()].sort((a,b)=>(getTimestamp(a)||0)-(getTimestamp(b)||0)||key(a).localeCompare(key(b)));
  };
  const limit=Math.min(200,Math.max(20,Number(args.limit)||100));
  let raw=[],method='',exhausted=false,latestMissing=false;
  const cursor=args.cursor||null;
  function before(list){
    if(!cursor)return list;
    // Use the actual anchor whenever present; timestamps are only a fallback.
    const index=list.findIndex(m=>key(m)===cursor.key);
    if(index>=0)return list.slice(0,index);
    return list.filter(m=>getTimestamp(m)!==null&&getTimestamp(m)<=cursor.timestamp);
  }
  if(typeof W?.chat?.getMessages==='function'){
    raw=await W.chat.getMessages(remoteId,{count:limit,direction:'before',...(cursor?{id:cursor.key}:{})});method='wpp.getMessages';
  }else{
    let all=pool(),anchor=cursor?(Msgs?.get?.(cursor.key)||all.find(m=>key(m)===cursor.key)):null;
    const newest=value(chat,'lastReceivedKey');
    if(!anchor&&!cursor){
      if(newest)try{anchor=Msgs?.get?.(newest)||Msgs?.get?.(serialized(newest));}catch{}
      if(newest&&!anchor&&typeof Msgs?.getMessagesById==='function'){
        const found=await Msgs.getMessagesById([serialized(newest)]);anchor=found?.messages?.[0];
      }
      if(!anchor)anchor=all.at(-1);
    }
    const resolvedNewest=!newest||serialized(value(anchor,'id'))===serialized(newest)||all.some(m=>key(m)===serialized(newest));
    if(!cursor&&anchor&&all.at(-1)&&(getTimestamp(all.at(-1))||0)>(getTimestamp(anchor)||0))anchor=all.at(-1);
    let anchorKey=!cursor&&newest&&!resolvedNewest?newest:anchor?value(anchor,'id'):null;
    if(!anchorKey&&cursor){
      const keyModule=module('WAWebMsgKey');
      const Key=keyModule?.default||keyModule?.MsgKey||W?.whatsapp?.MsgKey||value(all.at(-1),'id')?.constructor;
      if(typeof Key?.fromString==='function')anchorKey=Key.fromString(cursor.key);
    }
    const matchingAnchor=anchor&&serialized(value(anchor,'id'))===serialized(anchorKey);
    if(!cursor&&newest&&!resolvedNewest)latestMissing=true;
    if(anchorKey&&typeof query?.msgFindByDirection==='function'){
      const result=await query.msgFindByDirection({anchor:anchorKey,count:limit,direction:'before'});
      if(result?.status&&result.status!==200)throw new Error('Message query rejected its cursor (status '+result.status+'). Saved checkpoint retained.');
      raw=Array.isArray(result)?result:result?.messages;
      if(!Array.isArray(raw))throw new Error('Unsupported message-query response; no completeness claim made.');
      if(!cursor&&matchingAnchor)raw=[...raw,anchor];method='msgFindByDirection';
    }else if(typeof query?.msgFindQuery==='function'){
      const params={remote:value(chat,'id'),count:limit,direction:'before'};
      if(anchorKey)Object.assign(params,{id:value(anchorKey,'id'),fromMe:value(anchorKey,'fromMe'),participant:value(anchorKey,'participant')});
      const result=await query.msgFindQuery('before',params);raw=Array.isArray(result)?result:result?.messages;
      if(!Array.isArray(raw))throw new Error('Unsupported legacy message-query response.');
      if(!cursor&&matchingAnchor)raw=[...raw,anchor];method='msgFindQuery';
    }else{
      raw=before(all).slice(-limit);method='chat-message-collection';
      if(raw.length<limit){
        const loader=typeof load?.loadEarlierMsgs==='function'?()=>load.loadEarlierMsgs({chat}):typeof chat.loadEarlierMsgs==='function'?()=>chat.loadEarlierMsgs():null;
        if(loader){
          const loaded=await loader();
          const loadedArray=Array.isArray(loaded)?loaded:Array.isArray(loaded?.messages)?loaded.messages:[];
          all=[...new Map([...pool(),...all,...loadedArray].filter(m=>key(m)).map(m=>[key(m),m])).values()].sort((a,b)=>(getTimestamp(a)||0)-(getTimestamp(b)||0)||key(a).localeCompare(key(b)));
          raw=before(all).slice(-limit);method='loadEarlierMsgs';
          // Empty loading is an availability limit, not proof of server completeness.
          exhausted=loadedArray.length===0;
        }else if(!raw.length)throw new Error('No readable messages or compatible history loader in this WhatsApp version.');
      }
    }
  }
  const warnings=new Set(),messages=[];
  let invalid=latestMissing?1:0;
  if(latestMissing)warnings.add('The newest known message could not be resolved; latest-edge coverage remains partial.');
  const remoteOf=m=>serialized(value(value(m,'id'),'remote'));
  for(let m of raw){
    if(!m)continue;
    // Query results can be raw attributes. Prefer loaded models to recover derived names.
    try{m=Msgs?.get?.(key(m))||m;}catch{}
    const id=key(m),timestamp=getTimestamp(m),messageRemote=remoteOf(m);
    const serializedRemote=id.match(/^(?:true|false)_([^_]+)_/)?.[1];
    if(messageRemote&&messageRemote!==remoteId||serializedRemote&&serializedRemote!==remoteId)throw new Error('A message belongs to a different chat; batch rejected.');
    if(!id||!timestamp){invalid++;continue;}
    const dt=new Date(timestamp*1000),pad=n=>String(n).padStart(2,'0');
    if(!Number.isFinite(dt.getTime())){invalid++;continue;}
    const fromMe=Boolean(value(value(m,'id'),'fromMe')??value(m,'isSentByMe'));
    const senderId=serialized(value(m,'author')||value(value(m,'id'),'participant')||(fromMe?accountId:value(m,'from')));
    const senderModel=contact(senderId);
    const sender=fromMe?'You':contactName(senderModel)||clean(value(m,'notifyName'))||senderId||'Unknown sender';
    const type=String(value(m,'type')||'chat'),filename=clean(value(m,'filename')||value(value(m,'mediaData'),'filename'));
    const isMedia=!!filename||!!value(m,'isMedia')||['image','video','audio','ptt','document','sticker'].includes(type);
    const attachments=isMedia?[filename||`[${type}: original filename not exposed]`]:[];
    let text=String(value(m,'body')||value(m,'caption')||'');
    if(isMedia){text=String(value(m,'caption')||'');}
    if(!text&&!isMedia)text=`[${type} message: text unavailable]`;
    messages.push({key:id,date:`${dt.getFullYear()}-${pad(dt.getMonth()+1)}-${pad(dt.getDate())}`,time:`${pad(dt.getHours())}:${pad(dt.getMinutes())}:${pad(dt.getSeconds())}`,timestamp,sender,senderId,fromMe,text,attachments,type,source:'data'});
  }
  messages.sort((a,b)=>a.timestamp-b.timestamp||a.key.localeCompare(b.key));
  const unique=[...new Map(messages.map(m=>[m.key,m])).values()];
  if(invalid)warnings.add(invalid+' message records lack readable timestamps/IDs; coverage is partial.');
  if(!accountId)warnings.add('Account identity is unavailable; automatic account verification could not be performed.');
  const oldest=unique[0];
  return {remoteId,accountId,capabilities,method,messages:unique,warnings:[...warnings],invalid,exhausted,nextCursor:oldest?{key:oldest.key,timestamp:oldest.timestamp}:null};
  }catch(error){return {error:error?.message||String(error)};}
}
