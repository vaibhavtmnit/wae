/* Shared pure parsing functions; no WhatsApp internals or network requests. */
(function (root) {
  function parseMeta(meta, order) {
    const normalized = meta.replace(/[\u200e\u200f\u061c\u202a-\u202e\u2066-\u2069]/g, '').replace(/[\u202f\u00a0]/g, ' ').replace(/[\u0660-\u0669\u06f0-\u06f9\u0966-\u096f]/g, d => String(d.charCodeAt(0) >= 0x966 ? d.charCodeAt(0)-0x966 : d.charCodeAt(0) >= 0x6f0 ? d.charCodeAt(0)-0x6f0 : d.charCodeAt(0)-0x660));
    const m = normalized.match(/^\[(.+?),\s*(.+?)\]\s*([\s\S]*?):\s*$/);
    if (!m) return null;
    const parts = m[2].match(/^(\d{1,4})[/.\-](\d{1,2})[/.\-](\d{1,4})$/);
    const time = m[1].trim().match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?$/i);
    if (!parts || !time) return null;
    let a = +parts[1], b = +parts[2], c = +parts[3];
    let y, mo, d;
    if (parts[1].length === 4) [y, mo, d] = [a, b, c];
    else {
      if (order === 'auto') { if (a > 12 && b <= 12) order = 'dmy'; else if (b > 12 && a <= 12) order = 'mdy'; else if (a !== b) return null; }
      if (!['auto','dmy','mdy'].includes(order)) return null;
      [y, mo, d] = [c < 100 ? 2000 + c : c, order === 'dmy' ? b : a, order === 'dmy' ? a : b];
    }
    let h = +time[1];
    if (time[4]) { if (h < 1 || h > 12) return null; h = h % 12 + (/PM/i.test(time[4]) ? 12 : 0); }
    if (h > 23 || +time[2] > 59 || +(time[3] || 0) > 59) return null;
    const dt = new Date(y, mo - 1, d);
    if (dt.getFullYear() !== y || dt.getMonth() !== mo - 1 || dt.getDate() !== d) return null;
    const pad = n => String(n).padStart(2, '0');
    return {date: `${y}-${pad(mo)}-${pad(d)}`, time: `${pad(h)}:${time[2]}:${time[3] || '00'}`, sender: m[3], rawMetadata: meta};
  }
  function merge(old, batch) {
    const result = new Map(old.map(m => [m.key, m]));
    for (const m of batch) {
      const previous = result.get(m.key);
      result.set(m.key, previous ? {...previous, ...m, text:m.text || previous.text, attachments:[...new Set([...(previous.attachments || []), ...(m.attachments || [])])]} : m);
    }
    return [...result.values()].sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
  }
  function textExport(job, chat) {
    return [`Chat: ${chat.name}`, `Dates: ${job.start} to ${job.end} (inclusive; WhatsApp displayed local time)`,
      `Status: ${chat.status}`, `Coverage: ${chat.reason || 'In progress; incomplete'}`,
      `Warnings: ${(chat.warnings || []).join('; ') || 'None recorded'}`, '',
      ...(chat.messages || []).map(m => `[${m.date} ${m.time}] ${m.sender}: ${m.text}${m.attachments.length ? '\n' + m.attachments.map(f => `[Attachment: ${f}]`).join('\n') : ''}`)].join('\n');
  }
  function inferOrder(metadata) {
    const evidence = new Set();
    for (const meta of metadata) {
      const d = parseMeta(meta,'dmy'), m = parseMeta(meta,'mdy');
      if (d && !m) evidence.add('dmy'); else if (m && !d) evidence.add('mdy');
    }
    if (evidence.size > 1) throw new Error('Conflicting date formats detected. Check WhatsApp date settings.');
    return [...evidence][0] || null;
  }
  function identity(id) { return id?.match(/^(?:true|false)_([^_]+)_/)?.[1] || null; }
  root.ExporterCore = {parseMeta, merge, textExport, inferOrder, identity};
  if (typeof module !== 'undefined') module.exports = root.ExporterCore;
})(globalThis);
