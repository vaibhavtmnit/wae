# WhatsApp Period Exporter for Chrome — v0.4.1

Selected-chat, inclusive-date exports with local checkpoints, live progress and TXT/JSON downloads. No Python runtime or export server. Version 0.4 adds a **chat data-store engine**: it reads message models and loads earlier history through WhatsApp Web's runtime, without depending on chat clicks, header recognition, displayed date formats or rendered message elements.

The previous visible-page scraper remains available as an explicit legacy diagnostic mode. Data-store mode does not silently fall back to scraping when its runtime is unavailable. See [SOURCES.md](SOURCES.md) for the requested SaveMyChat/WAExport comparison and the open-source technical references used to implement this change.

## Install / update and use

1. In `chrome://extensions`, enable Developer mode and load this folder, or **Reload** the existing installation. Requires Chrome 120+. Version 0.4 adds Chrome's **scripting** permission for packaged code that reads the WhatsApp page runtime; host access remains limited to WhatsApp Web.
2. **Refresh WhatsApp Web after updating**, wait until signed in and chats finish loading, and reopen the exporter control page. Keep exactly one WhatsApp Web tab open.
3. Click **Find chats again** after upgrading so the saved list includes stable chat IDs. Available archived chats are included by data discovery. Identical names are distinguished by their IDs in the list.
4. Select chats, enter From/Through dates, and leave **Extraction method → Chat data store (recommended)** selected. Account label is optional. The date-order selector applies only to legacy mode; data mode uses Unix timestamps converted to browser local time.
5. Click **Start new export**. The button and nearby status immediately show startup steps. The dashboard then shows the active chat, loaded message batches, saved message count, oldest date seen, checkpoint age, partial results and overall chat progress.
6. Keep Chrome and the signed-in WhatsApp tab open. The control page can be closed. Each processed chat requests a TXT download; saved TXT/JSON files can be downloaded at any time from the control page.

Downloads use the chat name, such as `Vidhi Thakur.txt` or `Vidhi Thakur.json`, inside `Downloads/WhatsApp-exports/<job-id>/`. Unsupported filename characters are replaced. Chrome adds a suffix for duplicate names or repeated downloads instead of overwriting an existing file.

The data engine does not need to visibly open a conversation. A stationary WhatsApp page is normal while the dashboard records loaded batches/messages. If WhatsApp's runtime is still syncing or incompatible, the error names the data-store/read failure rather than a chat-header timeout. **Download diagnostics** includes capability detection, WhatsApp version when exposed, and the read method used.

## Resume and data retention

- Message records, counts and cursor/progress are committed together in strict IndexedDB transactions before the next batch. A shorter retry does not replace a longer saved result. Duplicate message IDs are updated without duplicating the message; existing nonempty text/filenames are preserved if a later read omits them.
- Pause invalidates run ownership immediately. Stale or competing runners cannot commit later results. Tab reload/close, Chrome restart, and two minutes without a checkpoint mark interruption. Resume requires verifying the intended signed-in account.
- Data-mode resume catches up newer pages, including more than one page of messages arriving during a pause, before continuing the saved older-history cursor. Watermarks advance only after catch-up records are checkpointed. Interrupted legacy jobs without stable IDs are resolved by a unique exact name; if ambiguous or unavailable, run Find chats and start a new job.
- Actual account IDs are bound when available and checked on subsequent reads; chat IDs are checked against saved selections. If runtime account identity is unavailable, a warning is retained. Account labels alone are not authentication. Never mix different accounts in a job.
- Earlier jobs remain saved. Pause before switching **Saved exports**. Original v0.1 `chrome.storage` checkpoints migrate to IndexedDB only after a successful transaction.
- Chrome Downloads events track file completion/interruption. Large files use Blob URLs instead of large data URLs. **File saved** refers to the download, not extraction completeness; empty/partial files are labelled accordingly. Chrome settings may request multiple-download permission or a save location. Saved database records survive download failures.

## Captured fields and coverage

Data mode captures stable message ID, sender/name or sender identifier, text/caption, message type, Unix timestamp, browser-local date/time, and exposed attachment filename. Outgoing messages are labelled `You` with a sender ID where available. Attachment bytes, thumbnails, media keys and downloaded media are excluded. Media without a filename gets an explicit placeholder. Unknown/non-text types may be represented by a labelled placeholder. Original messages are read separately from quoted replies.

`range-reached` means paging reached messages earlier than the requested start without known unreadable records; it is not proof that WhatsApp exposed every server message. Empty/stalled history, incompatible APIs, unresolved newest messages and unreadable IDs/timestamps produce partial results. All messages in a timestamp tie retain distinct stable IDs. Chat sorting uses timestamp and ID for ties.

The overall percentage measures **chats scanned**, including partial results. It does not estimate total message count or guarantee complete coverage. Current-chat activity is indeterminate because WhatsApp does not expose a dependable history total. Resume retries unfinished/partial chats and skips date-boundary results. Start a new job to rescan those.

WhatsApp's runtime is unofficial and changes over time. Browser throttling, logout, connectivity, tab discard and sleeping computers can interrupt work. Runtime loaders can access only history available to this device; older phone/server history may be unavailable. Export formatting still uses memory proportional to one chat. Saved exports accumulate on disk. Removing the extension or clearing its data deletes checkpoints. Keep normal WhatsApp backups; local extension data is not an encrypted backup.

## Legacy mode and diagnostics

**Visible page (legacy diagnostic mode)** retains the original English-interface DOM traversal. It has independent limits: virtualized/filter-hidden chats, unrecognised date metadata, unsupported headers, missing system events and incomplete media detection. Its timestamps require the correct explicit day/month order, or unambiguous evidence for automatic detection. It should not be used as a workaround for the live readiness failure without checking diagnostics.

Diagnostics contain versions, counts, errors, capabilities, and legacy observed-header text, but no message bodies or attachment payloads. Error/header text can contain chat names; review before sharing. No exported chat content is uploaded by this extension. The read bridge uses Chrome MAIN-world execution and returns results directly through the extension; it does not post message content into page DOM events.

## Verification

From the project root:

```powershell
node --test chrome-extension/core.test.cjs
python chrome-extension/data_browser_test.py
python chrome-extension/browser_test.py
```

Tests use isolated temporary Chromium profiles and locally intercepted fixture pages. The data suite runs with **no chat/message DOM at all** and exercises actual MAIN-world execution, native/collection history paging, stable duplicate-name selection, sender/filename fields, account checks, retries, saved cursors, new-message catch-up and the real Start button. The legacy suite verifies the independent DOM path and shared storage/progress/download controls. See [VALIDATION.md](VALIDATION.md).

These checks establish fixture behavior, not live WhatsApp compatibility. Before a large export, compare a small known chat/date range with WhatsApp and test a reload/resume. A completed fixture test must not be taken as confirmation that the user's live account works.
