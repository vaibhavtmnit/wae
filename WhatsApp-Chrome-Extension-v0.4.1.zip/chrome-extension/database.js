/* Transactions commit messages, counts and ownership together. */
(function(root) {
  const request = req => new Promise((resolve, reject) => { req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error); });
  let opening;
  function open() {
    return opening ||= new Promise((resolve, reject) => {
      const req = indexedDB.open('whatsapp-period-exporter', 1);
      req.onupgradeneeded = () => {
        req.result.createObjectStore('meta');
        req.result.createObjectStore('jobs', {keyPath: 'id'});
        req.result.createObjectStore('messages', {keyPath: ['chatId', 'key']}).createIndex('chatId', 'chatId');
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => { opening = null; reject(req.error); };
    });
  }
  async function transaction(mode, fn) {
    const db = await open();
    const tx = db.transaction(['meta', 'jobs', 'messages'], mode, mode === 'readwrite' ? {durability:'strict'} : {});
    const done = new Promise((resolve, reject) => { tx.oncomplete = resolve; tx.onabort = () => reject(tx.error || new Error('Save aborted; previous checkpoint retained.')); tx.onerror = () => {}; });
    try { const result = await fn(tx); await done; return result; }
    catch (e) { try { tx.abort(); } catch {} await done.catch(() => {}); throw e; }
  }
  async function current(tx, id) {
    id ||= await request(tx.objectStore('meta').get('active'));
    return id ? request(tx.objectStore('jobs').get(id)) : null;
  }
  function owned(job, msg, tabId) {
    if (!job || job.id !== msg.jobId || job.owner?.token !== msg.token || job.owner.tabId !== tabId || job.owner.deadline < Date.now()) throw new Error('Run ownership expired or was paused. Saved checkpoints are safe; resume from the control page.');
  }
  async function execute(msg, tabId) {
    return transaction(['snapshot', 'records','authorize'].includes(msg.type) ? 'readonly' : 'readwrite', async tx => {
      const jobs = tx.objectStore('jobs'), records = tx.objectStore('messages');
      let job = await current(tx, msg.jobId);
      if (msg.type === 'snapshot') return {job, jobs: (await request(jobs.getAll())).map(j => ({id:j.id,account:j.account,start:j.start,end:j.end,status:j.status}))};
      if (msg.type === 'records') {
        if (!job?.chats.some(c => c.id === msg.chatId)) throw new Error('Unknown saved chat');
        return {job, messages: (await request(records.index('chatId').getAll(msg.chatId))).map(({chatId, ...m}) => m)};
      }
      if(msg.type==='authorize'){owned(job,msg,tabId);return {job};}
      if (msg.type === 'create') {
        if (job?.owner && job.owner.deadline > Date.now()) throw new Error('Pause the active run before starting a new job.');
        job = msg.job;
        if (!job?.id || !job.chats?.length || !/^\d{4}-\d{2}-\d{2}$/.test(job.start) || !/^\d{4}-\d{2}-\d{2}$/.test(job.end) || job.start > job.end || !['auto','dmy','mdy'].includes(job.order)) throw new Error('Invalid export settings');
        jobs.add(job); tx.objectStore('meta').put(job.id, 'active');
      } else if (msg.type === 'activate') {
        const active = await current(tx);
        if (active?.owner && active.owner.deadline > Date.now()) throw new Error('Pause the active run first.');
        if (!job) throw new Error('Saved job not found');
        tx.objectStore('meta').put(job.id, 'active');
      } else if (msg.type === 'claim') {
        if (!job || job.id !== await request(tx.objectStore('meta').get('active'))) throw new Error('Job changed. Refresh the control page.');
        if (job.owner && job.owner.deadline > Date.now()) throw new Error('A run is already active. Pause it before resuming.');
        job.owner = {token: crypto.randomUUID(), tabId, deadline: Date.now() + 120000};
        job.status = 'running'; job.reason = ''; jobs.put(job);
      } else if (msg.type === 'checkpoint') {
        owned(job, msg, tabId);
        const chat = job.chats.find(c => c.id === msg.chatId);
        if (!chat) throw new Error('Unknown chat');
        if(msg.accountId&&job.accountId&&msg.accountId!==job.accountId)throw new Error('Signed-in account differs from the saved export');
        if(msg.accountId)job.accountId=msg.accountId;
        if(chat.remoteId&&msg.patch.remoteId&&chat.remoteId!==msg.patch.remoteId)throw new Error('Chat ID changed; saved history was retained');
        if (chat.identity && msg.patch.identity && chat.identity !== msg.patch.identity) throw new Error('Chat identity changed. Refusing to mix histories.');
        Object.assign(chat, msg.patch);
        job.currentChatId = chat.id;
        for (const m of msg.messages || []) {
          if (!m.key || !m.date || m.date < job.start || m.date > job.end) continue;
          const previous = await request(records.get([chat.id,m.key]));
          const record = previous ? ExporterCore.merge([previous],[m])[0] : m;
          records.put({...record, chatId: chat.id});
        }
        chat.count = await request(records.index('chatId').count(chat.id));
        chat.updatedAt = new Date().toISOString(); job.owner.deadline = Date.now() + 120000;
        job.updatedAt = chat.updatedAt; jobs.put(job);
      } else if (msg.type === 'downloadState') {
        const chat=job?.chats.find(c=>c.id===msg.chatId);
        if(!chat)throw new Error('Saved chat not found');
        if(!chat.download || msg.download.id>=chat.download.id){chat.download=msg.download;jobs.put(job);}
      } else if (msg.type === 'finish') {
        owned(job, msg, tabId);
        job.owner = null; job.currentChatId = null; job.status = job.chats.some(c => c.status !== 'range-reached') ? 'needs-review' : 'finished'; jobs.put(job);
      } else if (msg.type === 'pause' || msg.type === 'interrupt') {
        if (job) {
          if (msg.type === 'interrupt' && msg.expectedToken !== job.owner?.token) return {job};
          const owner = job.owner;
          job.owner = null; job.currentChatId = null; job.status = msg.type === 'pause' ? 'paused' : 'interrupted'; job.reason = msg.reason || 'Paused by user';
          job.chats.filter(c => c.status === 'running' || c.status === 'retrying').forEach(c => {c.status = job.status; c.reason = job.reason;});
          jobs.put(job); return {job, previousOwner: owner};
        }
      } else if (msg.type === 'import') {
        if (!job && msg.job) {
          job = {...msg.job, owner:null, status:'interrupted', reason:'Imported earlier checkpoints; resume to continue.'};
          for (const c of job.chats) for (const m of msg.records[c.id] || []) records.put({...m, chatId:c.id});
          jobs.put(job); tx.objectStore('meta').put(job.id, 'active');
        }
      } else throw new Error('Unknown storage command');
      return {job};
    });
  }
  root.ExportDB = {execute};
})(globalThis);
