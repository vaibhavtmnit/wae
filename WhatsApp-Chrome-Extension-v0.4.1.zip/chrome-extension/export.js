/* Blob URLs avoid embedding an entire large chat into a download request URL. */
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  if(sender.id!==chrome.runtime.id||msg.target!=='export-writer')return;
  if(msg.type==='releaseBlob'){URL.revokeObjectURL(msg.url);respond({ok:true});return;}
  if(msg.type!=='buildBlob')return;
  (async()=>{
    const {job,messages}=await ExportDB.execute({type:'records',jobId:msg.jobId,chatId:msg.chatId});
    const chat=job.chats.find(c=>c.id===msg.chatId);
    const body=msg.format==='json'?JSON.stringify({version:2,account:job.account,start:job.start,end:job.end,chat:{...chat,messages:ExporterCore.merge([],messages)}},null,2):ExporterCore.textExport(job,{...chat,messages:ExporterCore.merge([],messages)});
    return {url:URL.createObjectURL(new Blob([body],{type:msg.format==='json'?'application/json':'text/plain;charset=utf-8'})),name:chat.name};
  })().then(respond,e=>respond({error:e.message}));return true;
});
