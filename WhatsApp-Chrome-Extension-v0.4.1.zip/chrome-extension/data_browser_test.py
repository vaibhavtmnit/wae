"""Runtime/MAIN-world integration tests, without WhatsApp message DOM or external network.
python chrome-extension/data_browser_test.py
"""
import sys
# Chrome refuses extension directories containing reserved __pycache__ folders.
sys.dont_write_bytecode = True
import unittest
from playwright.sync_api import expect
import browser_test as legacy

DATA_FIXTURE = r'''<!doctype html><html><body><p>Signed-in runtime fixture. No conversation DOM is rendered.</p><script>
class Wid {constructor(id){this._serialized=id;}toString(){return this._serialized;}}
class MsgKey {
 constructor(remote,index,fromMe=false){this.remote=new Wid(remote);this.id='M'+String(index).padStart(4,'0');this.fromMe=fromMe;this.$1=String(fromMe)+'_'+remote+'_'+this.id;}
 toString(){return this.$1;}
 static fromString(s){const m=s.match(/^(true|false)_([^_]+)_M(\d+)$/);if(!m)throw Error('bad cursor');return new MsgKey(m[2],+m[3],m[1]==='true');}
}
const account='999@c.us';let loadCalls=0,queryCalls=0;
const histories=new Map(),chatModels=[];
for(const [remote,name] of [['111@c.us','Alice'],['222@g.us','Project'],['333@c.us','Duplicate'],['444@c.us','Duplicate']]){
 const records=Array.from({length:260},(_,i)=>{
   const day=i<80?8:i<160?10:20;
   const m={id:new MsgKey(remote,i,i%3===0),t:new Date(2026,9,day,9,0,Math.floor(i/2)).getTime()/1000,from:new Wid(remote),author:remote.endsWith('@g.us')?new Wid('555@c.us'):undefined,type:'chat',body:i===230||i===231?'identical text':'Message '+i,notifyName:'Friend',mediaKey:'SECRET_SHOULD_NEVER_BE_EXPORTED'};
   if(i===160)Object.assign(m,{type:'document',filename:'report.pdf',caption:'A document',body:'BINARY_THUMBNAIL'});
   if(i===161)Object.assign(m,{type:'image',filename:'photo.jpg',caption:'A photo',body:'BINARY_THUMBNAIL'});
   if(i===162)Object.assign(m,{type:'image',caption:'Unnamed photo',body:'BINARY_THUMBNAIL'});
   return m;
 });histories.set(remote,records);
 const msgs={models:records.slice(-20),getModelsArray(){return this.models;}};
 chatModels.push({attributes:{id:new Wid(remote),name,formattedTitle:name,msgs,lastReceivedKey:records.at(-1).id,archive:remote==='444@c.us'}});
}
const Chat={getModelsArray:()=>chatModels,get:id=>chatModels.find(c=>String(c.attributes.id)===String(id))};
const Msg={get(id){const s=String(id);return chatModels.flatMap(c=>c.attributes.msgs.models).find(m=>String(m.id)===s);}};
const Contact={get:id=>String(id)==='555@c.us'?{pushname:'Group member'}:null};
const modules={
 WAWebCollections:{Chat,Msg,Contact},
 WAWebUserPrefsMeUser:{getMaybeMeUser:()=>new Wid(window.switched?'888@c.us':account)},
 WAWebMsgKey:{default:MsgKey},
 WAWebDBMessageFindLocal:{async msgFindByDirection({anchor,count,direction}){
  queryCalls++;if(window.failOnce){window.failOnce=false;throw Error('Transient database unavailable');}
  if(window.slowRead)await new Promise(r=>setTimeout(r,500));
  const all=histories.get(String(anchor.remote)),index=all.findIndex(m=>String(m.id)===String(anchor));
  if(index<0)return {status:404,messages:[]};
  return {status:200,messages:all.slice(Math.max(0,index-count),index)};
 }},
 WAWebChatLoadMessages:{async loadEarlierMsgs({chat}){
  loadCalls++;const all=histories.get(String(chat.attributes.id)),first=all.indexOf(chat.attributes.msgs.models[0]);
  const loaded=all.slice(Math.max(0,first-100),first);chat.attributes.msgs.models.unshift(...loaded);return loaded;
 }}
};
window.require=name=>{if(window.noQuery&&name==='WAWebDBMessageFindLocal')return {};if(!modules[name])throw Error('Unknown module');return modules[name];};
window.Debug={VERSION:'fixture-runtime'};
</script></body></html>'''


class RuntimeTests(unittest.TestCase):
    rpc=legacy.ExtensionTests.rpc
    command=legacy.ExtensionTests.command
    wait_job=legacy.ExtensionTests.wait_job

    @classmethod
    def setUpClass(cls):
        legacy.ExtensionTests.setUpClass.__func__(cls)
        cls.context.unroute('https://web.whatsapp.com/**')
        cls.context.route('https://web.whatsapp.com/**',lambda route:route.fulfill(content_type='text/html',body=DATA_FIXTURE))

    @classmethod
    def tearDownClass(cls):
        legacy.ExtensionTests.tearDownClass.__func__(cls)

    def setUp(self):
        self.rpc({'type':'pause'})
        self.page.goto('https://web.whatsapp.com/')
        self.page.wait_for_timeout(200)

    def new_job(self,name='Alice',remote='111@c.us'):
        job=self.manager.evaluate('''()=>({id:crypto.randomUUID(),engine:'data',accountId:'999@c.us',account:'fixture',start:'2026-10-10',end:'2026-10-20',order:'auto',status:'paused',chats:[{id:crypto.randomUUID(),status:'pending',count:0}]})''')
        job['chats'][0].update(name=name,remoteId=remote)
        result=self.rpc({'type':'create','job':job})
        self.assertNotIn('error',result)
        return job

    def run_job(self,job):
        self.assertNotIn('error',self.command({'type':'resume','jobId':job['id']}))
        return self.wait_job(lambda j:j['status']!='running',60)

    def test_01_data_discovery_uses_ids_and_archived_chats(self):
        result=self.command({'type':'discover'})
        self.assertNotIn('error',result)
        self.assertEqual(len(result['chats']),4)
        self.assertEqual(len({c['remoteId'] for c in result['chats']}),4)
        self.assertEqual(sum(c['name']=='Duplicate' for c in result['chats']),2)
        self.assertTrue(next(c for c in result['chats'] if c['remoteId']=='444@c.us')['archived'])

    def test_02_native_pagination_has_no_dependency_on_chat_dom(self):
        job=self.new_job()
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['status'],'range-reached',state)
        self.assertEqual(state['chats'][0]['count'],180)
        self.assertEqual(state['chats'][0]['readMethod'],'msgFindByDirection')
        records=self.rpc({'type':'records','chatId':job['chats'][0]['id']})['messages']
        self.assertEqual(len({m['key'] for m in records}),180)
        self.assertEqual(sum(m['text']=='identical text' for m in records),2)
        self.assertIn('report.pdf',next(m for m in records if m['key'].endswith('M0160'))['attachments'])
        self.assertEqual(next(m for m in records if m['key'].endswith('M0160'))['text'],'A document')
        self.assertTrue(any('original filename not exposed' in f for m in records for f in m['attachments']))
        self.assertNotIn('mediaKey',str(records))
        self.assertNotIn('BINARY_THUMBNAIL',str(records))
        self.assertEqual(self.page.locator('[data-pre-plain-text]').count(),0)

    def test_03_collection_loader_fallback(self):
        self.page.evaluate('window.noQuery=true')
        job=self.new_job('Project','222@g.us')
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['count'],180,state)
        self.assertEqual(state['chats'][0]['status'],'range-reached',state)
        self.assertGreater(self.page.evaluate('loadCalls'),0)
        records=self.rpc({'type':'records','chatId':job['chats'][0]['id']})['messages']
        self.assertIn('Group member',{m['sender'] for m in records})

    def test_04_retry_and_resume_preserve_native_cursor(self):
        self.page.evaluate('window.slowRead=true')
        job=self.new_job()
        self.command({'type':'resume','jobId':job['id']})
        state=self.wait_job(lambda j:j['chats'][0]['count']>0,30)
        self.assertTrue(state['chats'][0]['cursor']['key'])
        count=state['chats'][0]['count']
        self.page.reload()
        self.wait_job(lambda j:j['status']=='interrupted',15)
        self.assertGreaterEqual(self.rpc({'type':'snapshot'})['job']['chats'][0]['count'],count)
        self.page.wait_for_timeout(200)
        self.page.evaluate('window.failOnce=true')
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['status'],'range-reached',state)
        self.assertEqual(state['chats'][0]['count'],180)

    def test_05_wrong_account_is_rejected(self):
        job=self.new_job()
        self.page.evaluate('window.switched=true')
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['count'],0)
        self.assertEqual(state['chats'][0]['status'],'partial')
        self.assertIn('account',state['chats'][0]['reason'])

    def test_06_actual_start_button_uses_data_engine(self):
        self.manager.reload()
        self.manager.locator('#discover').click()
        expect(self.manager.locator('#chats input')).to_have_count(4)
        self.manager.locator('#chats label').filter(has_text='Alice').locator('input').check()
        self.manager.locator('#start').fill('2026-10-10')
        self.manager.locator('#end').fill('2026-10-20')
        self.manager.locator('#startJob').click()
        expect(self.manager.locator('#actionStatus')).to_contain_text('Export started',timeout=15000)
        state=self.wait_job(lambda j:j['status']!='running',60)
        self.assertEqual(state['engine'],'data')
        self.assertEqual(state['chats'][0]['count'],180,state)
        expect(self.manager.locator('#progressPercent')).to_have_text('100%')

    def test_07_main_world_reads_require_runner(self):
        result=self.rpc({'type':'readData','command':'page','args':{'remoteId':'111@c.us'}})
        self.assertIn('WhatsApp main-frame runner',result['error'])

    def test_08_resume_catches_more_than_one_page_of_new_messages(self):
        self.page.evaluate('window.slowRead=true')
        job=self.new_job()
        self.command({'type':'resume','jobId':job['id']})
        self.wait_job(lambda j:j['chats'][0]['count']>0,30)
        self.rpc({'type':'pause'})
        self.page.reload()
        self.page.wait_for_timeout(200)
        self.page.evaluate('''()=>{
          const all=histories.get('111@c.us'),chat=Chat.get('111@c.us');
          for(let i=260;i<510;i++)all.push({id:new MsgKey('111@c.us',i),t:new Date(2026,9,20,11,0,i-260).getTime()/1000,type:'chat',body:'New '+i,from:new Wid('111@c.us')});
          chat.attributes.msgs.models=all.slice(-20);chat.attributes.lastReceivedKey=all.at(-1).id;
        }''')
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['count'],430,state)
        self.assertEqual(state['chats'][0]['status'],'range-reached',state)

    def test_09_outgoing_messages_after_last_received_key_are_included(self):
        self.page.evaluate('''()=>{
          const all=histories.get('111@c.us'),chat=Chat.get('111@c.us');
          const outgoing={id:new MsgKey('111@c.us',260,true),t:new Date(2026,9,20,12,0,0).getTime()/1000,type:'chat',body:'Newest outgoing',from:new Wid(account)};
          all.push(outgoing);chat.attributes.msgs.models.push(outgoing);
        }''')
        job=self.new_job()
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['count'],181,state)
        records=self.rpc({'type':'records','chatId':job['chats'][0]['id']})['messages']
        self.assertTrue(any(m['text']=='Newest outgoing' and m['sender']=='You' for m in records))

    def test_10_wrong_chat_batch_is_rejected_without_saving(self):
        self.page.evaluate("modules.WAWebDBMessageFindLocal.msgFindByDirection=async()=>({status:200,messages:histories.get('222@g.us').slice(-20)})")
        job=self.new_job()
        state=self.run_job(job)
        self.assertEqual(state['chats'][0]['count'],0,state)
        self.assertEqual(state['chats'][0]['status'],'partial',state)
        self.assertIn('different chat',state['chats'][0]['reason'])


if __name__=='__main__':
    unittest.main(verbosity=2)
