importScripts('core.js', 'database.js', 'runtime.js');
let initialization;
async function ready() {
  return initialization ||= (async () => {
    await chrome.storage.local.setAccessLevel({accessLevel:'TRUSTED_CONTEXTS'});
    const {job} = await ExportDB.execute({type:'snapshot'});
    if (!job) {
      const old = await chrome.storage.local.get(null);
      if (old.job) {
        const records = Object.fromEntries(old.job.chats.map(c => [c.id, old['messages:' + c.id] || []]));
        await ExportDB.execute({type:'import',job:old.job,records});
        await chrome.storage.local.remove(['job', ...old.job.chats.map(c => 'messages:' + c.id)]);
      }
    }
    await chrome.alarms.create('watch-export', {periodInMinutes:1});
    const entries=await chrome.storage.local.get(null);
    for(const key of Object.keys(entries).filter(k=>k.startsWith('download:'))){
      const id=Number(key.slice(9)),[item]=await chrome.downloads.search({id});
      if(!item||item.state!=='in_progress')await downloadFinished(id,item?.state||'interrupted',item?.error||(!item?'Download no longer exists':''));
    }
  })().catch(e => { initialization = null; throw e; });
}
function broadcast() { chrome.runtime.sendMessage({type:'progressChanged'}).catch(() => {}); }
let creatingWriter;
async function writer() {
  if(await chrome.offscreen.hasDocument())return;
  if(!creatingWriter)creatingWriter=chrome.offscreen.createDocument({url:'export.html',reasons:['BLOBS'],justification:'Create local Blob URLs for large saved chat exports.'}).finally(()=>{creatingWriter=null;});
  await creatingWriter;
}
async function download(msg) {
  const {job}=await ExportDB.execute({type:'snapshot',jobId:msg.jobId});
  if(!job)throw new Error('Saved job not found');
  await writer();
  const blob=await chrome.runtime.sendMessage({target:'export-writer',type:'buildBlob',jobId:job.id,chatId:msg.chatId,format:msg.format});
  if(!blob||blob.error)throw new Error(blob?.error||'Export writer did not respond');
  let name=Array.from(blob.name.replace(/[<>:"/\\|?*\u0000-\u001f]/g,'_')).slice(0,120).join('').replace(/^[ .]+|[ .]+$/g,'')||'chat';
  if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name))name='_'+name;
  try{
    const downloadId=await chrome.downloads.download({url:blob.url,filename:`WhatsApp-exports/${job.id}/${name}.${msg.format==='json'?'json':'txt'}`,conflictAction:'uniquify',saveAs:false});
    await chrome.storage.local.set({['download:'+downloadId]:{url:blob.url,jobId:job.id,chatId:msg.chatId}});
    await ExportDB.execute({type:'downloadState',jobId:job.id,chatId:msg.chatId,download:{id:downloadId,state:'in_progress'}});
    const [item]=await chrome.downloads.search({id:downloadId});
    if(item?.state!=='in_progress')await downloadFinished(downloadId,item?.state||'interrupted',item?.error);
    broadcast();return {downloadId};
  }catch(e){chrome.runtime.sendMessage({target:'export-writer',type:'releaseBlob',url:blob.url}).catch(()=>{});throw e;}
}
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('manager.html'), tabs = await chrome.tabs.query({url});
  if (tabs.length) await chrome.tabs.update(tabs[0].id,{active:true}); else await chrome.tabs.create({url});
});
chrome.runtime.onMessage.addListener((msg,sender,respond) => {
  if (sender.id !== chrome.runtime.id || !msg?.type || msg.type === 'progressChanged' || msg.target) return;
  const trusted = !sender.tab || sender.url?.startsWith(chrome.runtime.getURL(''));
  const content = sender.tab && sender.url?.startsWith('https://web.whatsapp.com/');
  if (!trusted && !content) return;
  (async () => {
    await ready();
    if(msg.type==='discoverData'||msg.type==='readData'){
      if(!content||sender.frameId!==0)throw new Error('Chat reads require the WhatsApp main-frame runner');
      let authorized;
      if(msg.type==='readData')authorized=await ExportDB.execute({type:'authorize',jobId:msg.jobId,token:msg.token},sender.tab.id);
      const savedChat=authorized?.job.chats.find(c=>c.id===msg.chatId);
      if(msg.type==='readData'&&!savedChat)throw new Error('Unknown selected chat');
      const command=msg.type==='discoverData'?'discover':msg.command;
      if(!['discover','resolve','page','probe'].includes(command))throw new Error('Read command not allowed');
      if(savedChat?.remoteId&&msg.args?.remoteId&&savedChat.remoteId!==msg.args.remoteId)throw new Error('Chat ID differs from the saved selection');
      const args=savedChat?{...msg.args,name:savedChat.name,remoteId:savedChat.remoteId||msg.args?.remoteId,accountId:authorized.job.accountId||savedChat.sourceAccountId||undefined}:{};
      let timer;
      const results=await Promise.race([
        chrome.scripting.executeScript({target:{tabId:sender.tab.id},world:'MAIN',func:readWhatsApp,args:[command,args]}),
        new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('WhatsApp data-store read timed out. Restore the WhatsApp tab and resume.')),25000);})
      ]).finally(()=>clearTimeout(timer));
      if(msg.type==='readData')await ExportDB.execute({type:'authorize',jobId:msg.jobId,token:msg.token},sender.tab.id);
      const result=results?.[0]?.result;
      if(!result)throw new Error('WhatsApp data reader returned no result. Check diagnostics for runtime compatibility.');
      return result;
    }
    if (msg.type === 'download') return download(msg);
    if (content && !['claim','checkpoint','finish'].includes(msg.type)) throw new Error('Unsupported page command');
    if (trusted && ['claim','checkpoint','finish','import'].includes(msg.type)) throw new Error('Runner command requires WhatsApp tab');
    const result = await ExportDB.execute(msg,sender.tab?.id);
    if (!['snapshot','records'].includes(msg.type)) broadcast();
    if (msg.type === 'pause' && result.previousOwner) chrome.tabs.sendMessage(result.previousOwner.tabId,{type:'stop'}).catch(() => {});
    return result;
  })().then(respond,e => respond({error:e.message || String(e)}));
  return true;
});
async function interrupt(reason,tabId) {
  await ready(); const {job} = await ExportDB.execute({type:'snapshot'});
  if (job?.owner && (tabId === undefined || job.owner.tabId === tabId)) { await ExportDB.execute({type:'interrupt',reason,expectedToken:job.owner.token}); broadcast(); }
}
chrome.tabs.onRemoved.addListener(id => { interrupt('WhatsApp tab closed. Open it and resume.',id).catch(console.error); });
chrome.tabs.onUpdated.addListener((id,change) => { if (change.status === 'loading') interrupt('WhatsApp page reloaded or navigated. Resume after it loads.',id).catch(console.error); });
chrome.alarms.onAlarm.addListener(async alarm => {
  if (alarm.name !== 'watch-export') return;
  try { await ready(); const {job} = await ExportDB.execute({type:'snapshot'}); if (job?.owner && job.owner.deadline < Date.now()) await interrupt('No checkpoint received for two minutes. Restore WhatsApp Web and resume.'); }
  catch(e) { console.error(e); }
});
chrome.runtime.onStartup.addListener(() => { interrupt('Chrome restarted. Verify your account and resume.').catch(console.error); });
chrome.runtime.onInstalled.addListener(() => { ready().then(broadcast).catch(console.error); });
async function downloadFinished(id,state,error){
  const key='download:'+id,entry=(await chrome.storage.local.get(key))[key];
  if(!entry)return;
  await ExportDB.execute({type:'downloadState',jobId:entry.jobId,chatId:entry.chatId,download:{id,state,error:error||''}});
  chrome.runtime.sendMessage({target:'export-writer',type:'releaseBlob',url:entry.url}).catch(()=>{});
  await chrome.storage.local.remove(key);broadcast();
}
chrome.downloads.onChanged.addListener(change=>{
  if(change.state?.current==='complete'||change.state?.current==='interrupted')downloadFinished(change.id,change.state.current,change.error?.current).catch(console.error);
});
