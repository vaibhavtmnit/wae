"""Isolated Chromium tests: no real WhatsApp account, profile or network required.
Run: python chrome-extension/browser_test.py
Requires the existing project's Playwright install and its Chromium browser.
"""
import tempfile
import time
import json
import unittest
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT = Path(__file__).resolve().parent
FIXTURE = r'''<!doctype html><html><head><style>
#side{width:250px;height:600px;float:left}#pane-side{height:400px;overflow:auto}
[role=row]{height:50px}#main{margin-left:260px;width:600px}#history{height:360px;overflow:auto;overflow-anchor:none}
.message-in{height:90px;box-sizing:border-box}header{height:50px}
</style></head><body><div id="side"><input type="search" aria-label="Search chats"><div id="pane-side"></div></div>
<div id="main"><header><span title=""></span></header><div id="history"></div></div>
<script>
const names=['Alice','Bob','Duplicate','Duplicate'];let active='Alice';
const history=document.querySelector('#history');
function rows(){const text=document.querySelector('input').value;document.querySelector('#pane-side').replaceChildren(...names.filter(n=>n.includes(text)).map(name=>{
 const row=document.createElement('div');row.setAttribute('role','row');row.innerHTML='<span title="'+name+'">'+name+'</span>';if(window.innerOnly)row.firstChild.addEventListener(window.innerEvent||'click',()=>open(name));else row.onclick=()=>open(name);return row;
}));}
document.querySelector('input').oninput=rows;
function render(){
 const start=Math.max(0,Math.floor(history.scrollTop/90)-1),end=Math.min(60,start+7);
 let html='<div style="height:'+start*90+'px"></div>';
 for(let i=start;i<end;i++){
 const day=window.ambiguous?10:i<20?8:i<40?10:20,month=window.ambiguous?11:10;
 html+='<div class="message-in" data-id="false_'+(active==='Alice'?'111':'222')+'@c.us_MSG'+i+'"><div data-pre-plain-text="[09:'+String(i%60).padStart(2,'0')+', '+day+'/'+month+'/2026] '+active+': "><span class="selectable-text copyable-text">Message '+i+'</span></div>'+(i===30?'<span title="report.pdf">report.pdf</span>':'')+'</div>';
 }html+='<div style="height:'+(60-end)*90+'px"></div>';history.innerHTML=html;if(window.noMetadata)history.querySelectorAll('[data-pre-plain-text]').forEach(e=>e.removeAttribute('data-pre-plain-text'));
}
history.onscroll=render;
function open(name){active=name;document.querySelector('header').innerHTML=window.plainHeader?'<button title="Profile details"><span title="Profile details">Info</span></button><span dir="auto">'+name+'</span>':'<span title="'+name+'">'+name+'</span>';render();history.scrollTop=history.scrollHeight;render();}
rows();open('Alice');
</script></body></html>'''


class ExtensionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='wa-extension-test-')
        cls.downloads = Path(cls.temp.name) / 'downloads'
        cls.downloads.mkdir()
        default = Path(cls.temp.name) / 'Default'
        default.mkdir()
        (default / 'Preferences').write_text(json.dumps({'download':{'default_directory':str(cls.downloads),'prompt_for_download':False}}))
        cls.p = sync_playwright().start()
        cls.context = cls.p.chromium.launch_persistent_context(
            cls.temp.name, channel='chromium', headless=True,
            args=[f'--disable-extensions-except={ROOT}', f'--load-extension={ROOT}'],
            accept_downloads=True, downloads_path=str(cls.downloads),
        )
        cls.worker = cls.context.service_workers[0] if cls.context.service_workers else cls.context.wait_for_event('serviceworker')
        cls.extension_id = cls.worker.url.split('/')[2]
        cls.context.route('https://web.whatsapp.com/**', lambda route: route.fulfill(content_type='text/html', body=FIXTURE))
        cls.page = cls.context.new_page()
        cls.page.goto('https://web.whatsapp.com/')
        cls.manager = cls.context.new_page()
        cls.manager.goto(f'chrome-extension://{cls.extension_id}/manager.html')
        cls.page.wait_for_timeout(700)

    @classmethod
    def tearDownClass(cls):
        cls.context.close()
        cls.p.stop()
        cls.temp.cleanup()

    def rpc(self, msg):
        return self.manager.evaluate('(msg)=>chrome.runtime.sendMessage(msg)', msg)

    def command(self, msg):
        return self.manager.evaluate('''async msg=>{
          const tabs=await chrome.tabs.query({url:'https://web.whatsapp.com/*'});
          return chrome.tabs.sendMessage(tabs[0].id,msg);
        }''', msg)

    def job(self, name='Alice'):
        return self.manager.evaluate('''name=>({id:crypto.randomUUID(),engine:'dom',account:'fixture',start:'2026-10-10',end:'2026-10-20',order:'dmy',status:'paused',chats:[{id:crypto.randomUUID(),name,status:'pending',count:0}]})''', name)

    def wait_job(self, predicate, timeout=90):
        until = time.monotonic() + timeout
        while time.monotonic() < until:
            job = self.rpc({'type':'snapshot'})['job']
            if predicate(job):
                return job
            self.manager.wait_for_timeout(150)
        self.fail(f'Timed out waiting for saved state: {job}')

    def test_01_discovery_detects_duplicates(self):
        result = self.command({'type':'discover'})
        self.assertNotIn('error', result)
        self.assertEqual({c['name'] for c in result['chats']}, {'Alice','Bob','Duplicate'})
        self.assertTrue(next(c for c in result['chats'] if c['name']=='Duplicate')['ambiguous'])

    def test_02_transactions_fence_stale_runners_and_rollback(self):
        job = self.job()
        result = self.rpc({'type':'create','job':job})
        self.assertNotIn('error', result)
        # Exercise real IndexedDB transactions, including concurrent claims.
        result = self.worker.evaluate('''async id=>{
          const results=await Promise.allSettled([ExportDB.execute({type:'claim',jobId:id},10),ExportDB.execute({type:'claim',jobId:id},11)]);
          return results.map(r=>({status:r.status,job:r.value?.job}));
        }''', job['id'])
        self.assertEqual([r['status'] for r in result].count('fulfilled'), 1)
        claim = next(r['job'] for r in result if r['status']=='fulfilled')
        token, owner = claim['owner']['token'], claim['owner']['tabId']
        checkpoint = {'type':'checkpoint','jobId':job['id'],'chatId':job['chats'][0]['id'],'token':token,'patch':{'status':'running','identity':'111@c.us'},'messages':[{'key':'one','date':'2026-10-10','time':'09:00:00','sender':'Alice','text':'saved','attachments':[]}]}
        for _ in range(2):
            self.worker.evaluate('([msg,tab])=>ExportDB.execute(msg,tab)', [checkpoint, owner])
        self.assertEqual(self.rpc({'type':'snapshot'})['job']['chats'][0]['count'], 1)
        # Invalid key triggers an IndexedDB error after a patch, and must roll back both.
        broken = {**checkpoint,'patch':{'reason':'MUST ROLL BACK'},'messages':[{**checkpoint['messages'][0],'key':{}}]}
        with self.assertRaises(Exception):
            self.worker.evaluate('([msg,tab])=>ExportDB.execute(msg,tab)', [broken, owner])
        self.assertNotEqual(self.rpc({'type':'snapshot'})['job']['chats'][0].get('reason'), 'MUST ROLL BACK')
        self.rpc({'type':'pause'})
        with self.assertRaises(Exception):
            self.worker.evaluate('([msg,tab])=>ExportDB.execute(msg,tab)', [checkpoint, owner])
        self.assertEqual(len(self.rpc({'type':'records','chatId':job['chats'][0]['id']})['messages']), 1)

    def test_03_virtualized_history_and_export(self):
        job = self.job()
        self.assertNotIn('error', self.rpc({'type':'create','job':job}))
        self.assertNotIn('error', self.command({'type':'resume','jobId':job['id']}))
        self.wait_job(lambda j: j['chats'][0]['count'] > 0, 30)
        expect(self.manager.locator('#currentWork')).to_be_visible()
        expect(self.manager.locator('#currentChat')).to_contain_text('Chat 1 of 1: Alice')
        expect(self.manager.locator('#runStatus')).to_have_text('Export running')
        expect(self.manager.locator('#currentDetails')).to_contain_text('messages saved')
        self.wait_job(lambda j: j['status'] != 'running')
        state = self.rpc({'type':'snapshot'})['job']
        self.assertEqual(state['chats'][0]['status'], 'range-reached', state)
        records = self.rpc({'type':'records','chatId':job['chats'][0]['id']})['messages']
        self.assertEqual(len(records), 40)
        expect(self.manager.locator('#overallProgress')).to_have_attribute('value','1')
        expect(self.manager.locator('#progressPercent')).to_have_text('100%')
        expect(self.manager.locator('#messageTotal')).to_have_text('40')
        expect(self.manager.locator('#currentWork')).to_be_hidden()
        self.assertEqual({m['text'] for m in records}, {f'Message {i}' for i in range(20,60)})
        self.assertIn('report.pdf', next(m for m in records if m['text']=='Message 30')['attachments'])
        self.assertNotIn('error', self.rpc({'type':'download','chatId':job['chats'][0]['id'],'format':'json'}))
        self.wait_job(lambda j: j['chats'][0].get('download',{}).get('state') == 'complete', 15)

    def test_04_reload_keeps_checkpoints_and_resume_deduplicates(self):
        job = self.job('Bob')
        self.rpc({'type':'create','job':job})
        self.assertNotIn('error', self.command({'type':'resume','jobId':job['id']}))
        self.wait_job(lambda j: j['chats'][0]['count'] > 0, 30)
        before = self.rpc({'type':'snapshot'})['job']['chats'][0]['count']
        self.manager.reload()
        expect(self.manager.locator('#currentChat')).to_contain_text('Bob')
        expect(self.manager.locator('#currentWork')).to_be_visible()
        self.page.reload()
        self.wait_job(lambda j: j['status'] == 'interrupted', 15)
        self.assertGreaterEqual(self.rpc({'type':'snapshot'})['job']['chats'][0]['count'], before)
        expect(self.manager.locator('#runStatus')).to_contain_text('Interrupted')
        expect(self.manager.locator('#currentWork')).to_be_hidden()
        self.page.wait_for_timeout(500)
        self.assertNotIn('error', self.command({'type':'resume','jobId':job['id']}))
        self.wait_job(lambda j: j['status'] != 'running')
        self.assertEqual(self.rpc({'type':'snapshot'})['job']['chats'][0]['count'], 40)
        # Previous jobs survive new exports and can be reactivated.
        self.assertGreaterEqual(len(self.rpc({'type':'snapshot'})['jobs']), 3)

    def test_05_changed_chat_stops_without_mixing_messages(self):
        job = self.job()
        self.rpc({'type':'create','job':job})
        self.command({'type':'resume','jobId':job['id']})
        self.wait_job(lambda j: j['chats'][0]['count'] > 0, 30)
        self.page.evaluate("open('Bob')")
        state = self.wait_job(lambda j: j['status'] != 'running')
        self.assertEqual(state['chats'][0]['status'], 'partial')
        self.assertIn('changed', state['chats'][0]['reason'])
        records = self.rpc({'type':'records','chatId':job['chats'][0]['id']})['messages']
        self.assertTrue(records)
        self.assertEqual({m['sender'] for m in records}, {'Alice'})

    def test_06_auto_dates_refuse_to_guess(self):
        self.page.evaluate('window.ambiguous=true;render()')
        job = self.job()
        job['order'] = 'auto'
        self.rpc({'type':'create','job':job})
        self.assertNotIn('error', self.command({'type':'resume','jobId':job['id']}))
        state = self.wait_job(lambda j: j['status'] != 'running', 30)
        self.assertIn('ambiguous', state['chats'][0]['reason'])
        self.assertEqual(state['chats'][0]['count'], 0)
        self.page.evaluate('window.ambiguous=false;render()')

    def test_07_missing_scroller_reports_partial(self):
        self.page.evaluate("history.style.overflow='visible'")
        job = self.job()
        self.rpc({'type':'create','job':job})
        self.command({'type':'resume','jobId':job['id']})
        state = self.wait_job(lambda j: j['status'] != 'running', 30)
        self.assertEqual(state['chats'][0]['status'], 'partial')
        self.assertTrue(any('newest edge' in w for w in state['chats'][0]['warnings']))
        self.page.evaluate("history.style.overflow='auto'")

    def test_08_worker_restart_retains_saved_data(self):
        before = self.rpc({'type':'snapshot'})['job']
        versions = []
        session = self.context.new_cdp_session(self.manager)
        session.on('ServiceWorker.workerVersionUpdated', lambda event: versions.extend(event['versions']))
        session.send('ServiceWorker.enable')
        self.manager.wait_for_timeout(300)
        candidates = [v for v in versions if v.get('scriptURL','').endswith('/background.js') and v.get('runningStatus')=='running']
        self.assertTrue(candidates, versions)
        session.send('ServiceWorker.stopWorker', {'versionId':candidates[-1]['versionId']})
        self.manager.wait_for_timeout(300)
        after = self.rpc({'type':'snapshot'})['job']
        self.assertEqual(after['id'], before['id'])
        self.assertEqual(after['chats'][0]['count'], before['chats'][0]['count'])
        self.assertNotIn('error', self.rpc({'type':'download','chatId':after['chats'][0]['id']}))
        session.detach()

    def test_10_mixed_results_progress_is_not_a_completeness_claim(self):
        job = self.job()
        job['status'] = 'needs-review'
        job['chats'][0].update(status='range-reached',count=5)
        job['chats'].extend([
            {'id':'partial-card','name':'Partial chat','status':'partial','count':3},
            {'id':'pending-card','name':'Pending chat','status':'pending','count':0},
        ])
        self.assertNotIn('error',self.rpc({'type':'create','job':job}))
        expect(self.manager.locator('#progressPercent')).to_have_text('67%')
        expect(self.manager.locator('#overallProgress')).to_have_attribute('max','3')
        expect(self.manager.locator('#overallProgress')).to_have_attribute('value','2')
        expect(self.manager.locator('#messageTotal')).to_have_text('8')
        expect(self.manager.locator('#rangeTotal')).to_have_text('1')
        expect(self.manager.locator('#partialTotal')).to_have_text('1')
        expect(self.manager.locator('#remainingTotal')).to_have_text('1')
        expect(self.manager.locator('#runStatus')).to_have_text('Finished with partial results')

    def test_11_start_button_without_account_label_starts_and_reports_status(self):
        self.page.reload()
        self.page.wait_for_timeout(400)
        self.manager.evaluate("()=>chrome.storage.local.set({discovered:[{name:'Alice'}]})")
        self.manager.reload()
        self.manager.locator('#chats input[type=checkbox]').check()
        self.manager.locator('#start').fill('2026-10-10')
        self.manager.locator('#end').fill('2026-10-20')
        self.manager.locator('#account').fill('')
        self.manager.locator('#engine').select_option('dom')
        self.manager.locator('#startJob').click()
        expect(self.manager.locator('#actionStatus')).to_contain_text('Export started', timeout=15000)
        self.wait_job(lambda j:j['chats'][0]['count']>0,30)
        self.assertEqual(self.rpc({'type':'snapshot'})['job']['account'],'Default account')
        expect(self.manager.locator('#currentChat')).to_contain_text('Alice')
        self.manager.locator('#pause').click()
        expect(self.manager.locator('#actionStatus')).to_contain_text('Paused.')
        self.page.wait_for_timeout(500)

    def test_12_start_validation_is_visible_next_to_button(self):
        self.manager.reload()
        expect(self.manager.locator('#chats input[type=checkbox]')).to_be_visible()
        self.manager.locator('#startJob').click()
        expect(self.manager.locator('#actionStatus')).to_contain_text('Select at least one chat')
        expect(self.manager.locator('#actionStatus')).to_have_class('action-status error')
        expect(self.manager.locator('#startJob')).to_be_enabled()
        self.manager.locator('#chats input[type=checkbox]').check()
        self.manager.locator('#start').fill('')
        self.manager.locator('#startJob').click()
        expect(self.manager.locator('#actionStatus')).to_contain_text('Choose both From and Through')

    def test_13_start_reports_unresponsive_tab_and_recovers_button(self):
        self.manager.evaluate("()=>chrome.storage.local.set({discovered:[{name:'Alice'}]})")
        self.manager.reload()
        self.manager.locator('#chats input[type=checkbox]').check()
        self.manager.locator('#start').fill('2026-10-10')
        self.manager.locator('#end').fill('2026-10-20')
        self.manager.evaluate('''()=>{window.originalSend=chrome.tabs.sendMessage;chrome.tabs.sendMessage=()=>new Promise(()=>{});}''')
        try:
            self.manager.locator('#startJob').click()
            expect(self.manager.locator('#actionStatus')).to_contain_text('Connecting to WhatsApp')
            expect(self.manager.locator('#runStatus')).to_contain_text('Connecting to WhatsApp')
            expect(self.manager.locator('#startJob')).to_have_text('Starting…')
            expect(self.manager.locator('#actionStatus')).to_contain_text('timed out',timeout=15000)
            expect(self.manager.locator('#actionStatus')).to_have_class('action-status error')
            expect(self.manager.locator('#startJob')).to_be_enabled()
            expect(self.manager.locator('#startJob')).to_have_text('Start new export')
        finally:
            self.manager.evaluate('()=>{chrome.tabs.sendMessage=window.originalSend;}')

    def test_14_inner_pointer_target_plain_header_and_changed_panel(self):
        self.page.reload()
        self.page.wait_for_timeout(300)
        self.page.evaluate('''()=>{
          window.innerOnly=true;window.innerEvent='pointerdown';window.plainHeader=true;
          const panel=document.querySelector('#main');panel.removeAttribute('id');panel.setAttribute('role','main');panel.style.cssText='margin-left:260px;width:600px';
          rows();open('Alice');
        }''')
        job=self.job('Bob')
        self.assertNotIn('error',self.rpc({'type':'create','job':job}))
        self.assertNotIn('error',self.command({'type':'resume','jobId':job['id']}))
        state=self.wait_job(lambda j:j['status']!='running')
        self.assertEqual(state['chats'][0]['status'],'range-reached',state)
        self.assertEqual(state['chats'][0]['count'],40)
        self.assertEqual(state['chats'][0]['navigation']['stage'],'ready')
        self.assertEqual(state['chats'][0]['navigation']['observedHeader'],'Bob')

    def test_15_open_chat_missing_date_metadata_is_diagnosed(self):
        self.page.reload()
        self.page.wait_for_timeout(300)
        self.page.evaluate('window.noMetadata=true;open("Bob")')
        job=self.job('Bob')
        self.rpc({'type':'create','job':job})
        self.command({'type':'resume','jobId':job['id']})
        state=self.wait_job(lambda j:j['status']!='running',45)
        chat=state['chats'][0]
        self.assertEqual(chat['status'],'partial')
        self.assertIn('unsupported date-metadata layout',chat['reason'])
        self.assertEqual(chat['count'],0)
        self.assertEqual(chat['navigation']['stage'],'messages-unavailable')
        self.assertTrue(chat['navigation']['headerMatched'])
        self.assertGreater(chat['navigation']['messageContainers'],0)
        self.assertEqual(chat['navigation']['messageMetadata'],0)

    def test_16_already_open_chat_needs_no_sidebar_search(self):
        self.page.reload()
        self.page.wait_for_timeout(300)
        self.page.evaluate('''()=>{open('Bob');document.querySelector('#side').remove();}''')
        job=self.job('Bob')
        self.rpc({'type':'create','job':job})
        self.command({'type':'resume','jobId':job['id']})
        state=self.wait_job(lambda j:j['status']!='running')
        self.assertEqual(state['chats'][0]['status'],'range-reached',state)
        self.assertEqual(state['chats'][0]['count'],40)

    def test_17_legacy_visible_chat_must_match_selected_stable_id(self):
        self.page.reload()
        self.page.wait_for_timeout(300)
        job=self.job()
        job['chats'][0]['remoteId']='999@c.us'
        self.assertNotIn('error',self.rpc({'type':'create','job':job}))
        self.command({'type':'resume','jobId':job['id']})
        state=self.wait_job(lambda j:j['status']!='running',30)
        self.assertEqual(state['chats'][0]['count'],0,state)
        self.assertEqual(state['chats'][0]['status'],'partial',state)
        self.assertIn('differs from the selected chat',state['chats'][0]['reason'])

    def test_09_emoji_linebreaks_quotes_and_unusual_filenames(self):
        self.page.add_script_tag(path=str(ROOT / 'core.js'))
        self.page.add_script_tag(path=str(ROOT / 'dom.js'))
        result = self.page.evaluate('''()=>{
          document.querySelector('#main').innerHTML=`<div data-id="false_111@c.us_SAMPLE">
            <div data-pre-plain-text="[09:00, 20/10/2026] Alice: "><span class="selectable-text copyable-text">Hello<img alt="🙂"><br>Next</span></div>
            <div data-testid="quoted-message"><span class="selectable-text copyable-text">Quoted Bob message</span></div>
            <span title="script.py">script.py</span><span data-testid="document-filename">LICENSE</span>
          </div>`;
          return ExportDOM.read('dmy');
        }''')
        self.assertEqual(result['messages'][0]['text'], 'Hello🙂\nNext')
        self.assertEqual(set(result['messages'][0]['attachments']), {'script.py','LICENSE'})
        # Some layouts expose a body wrapper while its header is a sibling.
        wrapped=self.page.evaluate('''()=>{
          document.querySelector('#main').outerHTML='<section role="main"><header><span dir="auto">Alice</span></header><div data-testid="conversation-panel-wrapper"><div data-pre-plain-text="[09:00, 20/10/2026] Alice: ">Hello</div></div></section>';
          return {header:ExportDOM.headerName(),messages:ExportDOM.metadata().length};
        }''')
        self.assertEqual(wrapped,{'header':'Alice','messages':1})


if __name__ == '__main__':
    unittest.main(verbosity=2)
